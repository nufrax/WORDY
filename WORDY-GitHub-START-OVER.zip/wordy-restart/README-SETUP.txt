WORDY GitHub Actions setup

This bundle contains:
- WORDY-source.zip: the original WORDY project archive
- .github/workflows/build-wordy-from-zip.yml: GitHub Actions workflow

Create a NEW empty GitHub repository.
Upload WORDY-source.zip to the repository root.
Create the file .github/workflows/build-wordy-from-zip.yml and paste the workflow contents from this bundle.
Commit to the main branch.
Open Actions and run "Build WORDY Android APK" (or wait for the push workflow).
Download the WORDY-Android-APK artifact from a successful run.

This produces a DEBUG APK for testing. It is not a signed release APK.
