let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioCtx) {
      audioCtx = new AudioCtx();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

function playTone(
  freq: number,
  duration: number,
  type: OscillatorType = 'sine',
  gainValue = 0.08,
  delay = 0
) {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime + delay;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, now);

  gain.gain.setValueAtTime(0.001, now);
  gain.gain.exponentialRampToValueAtTime(gainValue, now + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(now);
  osc.stop(now + duration + 0.02);
}

export const soundFx = {
  key(enabled: boolean) {
    if (!enabled) return;
    playTone(520, 0.06, 'triangle', 0.06);
  },
  delete(enabled: boolean) {
    if (!enabled) return;
    playTone(320, 0.06, 'sine', 0.05);
  },
  flip(enabled: boolean, index = 0) {
    if (!enabled) return;
    playTone(420 + index * 55, 0.08, 'triangle', 0.05, index * 0.06);
  },
  error(enabled: boolean) {
    if (!enabled) return;
    playTone(180, 0.14, 'sawtooth', 0.06);
    playTone(150, 0.16, 'sawtooth', 0.05, 0.08);
  },
  match(enabled: boolean) {
    if (!enabled) return;
    playTone(523.25, 0.1, 'triangle', 0.08, 0);
    playTone(659.25, 0.12, 'triangle', 0.08, 0.07);
    playTone(783.99, 0.18, 'triangle', 0.09, 0.14);
  },
  coin(enabled: boolean) {
    if (!enabled) return;
    playTone(987.77, 0.09, 'sine', 0.08, 0);
    playTone(1318.51, 0.2, 'sine', 0.09, 0.07);
  },
  victory(enabled: boolean) {
    if (!enabled) return;
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((n, idx) => {
      playTone(n, 0.22, 'triangle', 0.09, idx * 0.09);
    });
  },
  powerup(enabled: boolean) {
    if (!enabled) return;
    playTone(440, 0.08, 'square', 0.05, 0);
    playTone(660, 0.09, 'square', 0.05, 0.06);
    playTone(880, 0.14, 'triangle', 0.07, 0.12);
  },
};

export function triggerHaptic(enabled: boolean, pattern: number | number[] = 18) {
  if (!enabled) return;
  if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
    try {
      navigator.vibrate(pattern);
    } catch {
      // Ignore environments blocking vibration
    }
  }
}
