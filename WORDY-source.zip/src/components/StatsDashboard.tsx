import React from 'react';
import { BarChart3, Flame, Trophy } from 'lucide-react';
import {
  Bar,
  BarChart,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ACHIEVEMENT_BADGES } from '../services/playerService';
import { PlayerProfile } from '../types/game';
import { UzcCoinIcon } from './GameIcons';

interface StatsDashboardProps {
  profile: PlayerProfile;
  onOpenProfile: () => void;
}

export const StatsDashboard: React.FC<StatsDashboardProps> = ({
  profile,
  onOpenProfile,
}) => {
  const { stats } = profile;

  const winEligiblePlayed = stats.classicPlayed + stats.duelsPlayed + stats.dailyCompleted;
  const totalWins = stats.classicWon + stats.duelsWon + stats.dailyCompleted;
  const winRate =
    winEligiblePlayed > 0 ? Math.round((totalWins / winEligiblePlayed) * 100) : 0;

  const totalSessions =
    stats.classicPlayed + stats.dailyCompleted + stats.mixedSolved + stats.duelsPlayed;

  const unlockedBadgesCount = ACHIEVEMENT_BADGES.filter(
    (b) => profile.tasks[b.id]?.claimed
  ).length;

  const chartData = [
    { name: 'Classic', value: stats.classicPlayed, color: '#FBBF24' },
    { name: 'Daily', value: stats.dailyCompleted, color: '#FB7185' },
    { name: 'Mixed', value: stats.mixedSolved, color: '#A78BFA' },
    { name: 'Circle', value: stats.circleWordsFound, color: '#38BDF8' },
    { name: 'Duel', value: stats.duelsPlayed, color: '#34D399' },
  ];

  const hasAnyActivity = chartData.some((d) => d.value > 0);

  return (
    <section
      aria-label="Oʻyinchi statistikasi"
      className="rounded-2xl bg-slate-950/55 border border-white/20 p-3 sm:p-3.5 text-white flex flex-col gap-2.5 min-w-0"
    >
      {/* Header row */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <BarChart3 className="w-4 h-4 text-amber-300 shrink-0" />
          <h2 className="font-display font-bold text-xs sm:text-sm tracking-wide uppercase truncate">
            Statistika va Natijalar
          </h2>
        </div>

        <button
          type="button"
          onClick={onOpenProfile}
          className="px-2.5 py-1 rounded-lg bg-white/12 hover:bg-white/20 border border-white/20 text-[11px] font-bold text-amber-200 flex items-center gap-1 cursor-pointer shrink-0 transition-colors"
        >
          <Trophy className="w-3 h-3" />
          <span>
            {unlockedBadgesCount}/{ACHIEVEMENT_BADGES.length} Nishon
          </span>
        </button>
      </div>

      {/* 3 KPI Stat Tiles */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-xl bg-black/30 border border-white/10 px-2.5 py-2 min-w-0">
          <div className="text-[10px] font-semibold text-white/70 truncate">
            Gʻalaba foizi
          </div>
          <div className="font-mono-num font-bold text-sm sm:text-base text-emerald-300 mt-0.5">
            {winRate}%
          </div>
        </div>

        <div className="rounded-xl bg-black/30 border border-white/10 px-2.5 py-2 min-w-0">
          <div className="text-[10px] font-semibold text-white/70 truncate">
            Oʻynalgan
          </div>
          <div className="font-mono-num font-bold text-sm sm:text-base text-sky-300 mt-0.5">
            {totalSessions}
          </div>
        </div>

        <div className="rounded-xl bg-black/30 border border-white/10 px-2.5 py-2 min-w-0">
          <div className="text-[10px] font-semibold text-white/70 truncate">
            Jami UZC
          </div>
          <div className="font-mono-num font-bold text-sm sm:text-base text-amber-300 mt-0.5 flex items-center gap-1">
            <UzcCoinIcon className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{stats.totalUzcEarned}</span>
          </div>
        </div>
      </div>

      {/* Recharts Bar Visualization */}
      <div className="rounded-xl bg-black/25 border border-white/10 px-2 pt-2 pb-1 min-w-0">
        <div className="flex items-center justify-between px-1 mb-1">
          <span className="text-[10px] font-semibold text-white/70">
            Rejimlar faolligi
          </span>
          <span className="font-mono-num text-[10px] font-bold text-orange-300 flex items-center gap-1">
            <Flame className="w-3 h-3" />
            Seriya: {stats.currentWinStreak} (Rekord {stats.bestWinStreak})
          </span>
        </div>

        <div className="w-full h-[112px] sm:h-[126px] min-w-0">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 6, right: 6, left: -24, bottom: 0 }}
            >
              <XAxis
                dataKey="name"
                tick={{ fill: '#E2E8F0', fontSize: 10, fontWeight: 700 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                allowDecimals={false}
                tick={{ fill: '#94A3B8', fontSize: 10 }}
                axisLine={false}
                tickLine={false}
                domain={[0, hasAnyActivity ? 'auto' : 5]}
              />
              <Tooltip
                cursor={{ fill: 'rgba(255,255,255,0.08)' }}
                contentStyle={{
                  backgroundColor: '#0F172A',
                  borderColor: 'rgba(251,191,36,0.45)',
                  borderRadius: '12px',
                  fontSize: '11px',
                  fontWeight: 700,
                  color: '#F8FAFC',
                  padding: '6px 10px',
                }}
                formatter={(value) => [`${value ?? 0} ta`, 'Natija']}
              />
              <Bar dataKey="value" radius={[6, 6, 0, 0]} maxBarSize={32}>
                {chartData.map((entry) => (
                  <Cell key={entry.name} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </section>
  );
};
