import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  Bot,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  Globe,
  Pause,
  Play,
  RefreshCw,
  ShieldAlert,
  SlidersHorizontal,
  Smartphone,
  Sparkles,
  Swords,
  WifiOff,
  Zap,
} from 'lucide-react';
import {
  evaluateWordleGuess,
  getDuelWordsFromSeed,
  validateWordRealtime,
  WORDS_5_VALID,
  WORDS_6_VALID,
} from '../data/words';
import {
  createOnlineDuelRoom,
  DUEL_VARIANT_META,
  joinOnlineDuelRoom,
  startOnlineDuelRoom,
  subscribeToDuelRoom,
  updateOnlineDuelProgress,
} from '../services/duelService';
import { auth } from '../firebase';
import {
  DuelConnectionType,
  DuelPlayerState,
  DuelRoom,
  DuelVariant,
  LetterState,
  PlayerProfile,
  VictoryReward,
} from '../types/game';
import { soundFx, triggerHaptic } from '../utils/sound';
import { PlayerAvatarSvg, UzcCoinIcon } from './GameIcons';
import { WordKeyboard } from './WordKeyboard';
import { VictoryModal } from './VictoryModal';

interface TogetherModeProps {
  profile: PlayerProfile;
  isSignedIn: boolean;
  onSignIn: () => Promise<void>;
  onBack: () => void;
  onUsePowerup: (key: 'revealLetter' | 'freezeTime' | 'scrambleRival') => boolean;
  onFinishDuel: (won: boolean, rewardUzc: number, rewardXp: number) => void;
}

const MAX_DUEL_GUESSES = 6;
const TURN_DURATION_SECONDS = 45;
const ROUND_OPTIONS = [1, 3, 5, 6, 8, 10] as const;
const DURATION_OPTIONS = [
  { sec: 60, label: '1 daq' },
  { sec: 120, label: '2 daq' },
  { sec: 180, label: '3 daq' },
  { sec: 300, label: '5 daq' },
  { sec: 420, label: '7 daq' },
] as const;

const SEED_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function generateSeed4(): string {
  let out = '';
  for (let i = 0; i < 4; i++) {
    out += SEED_CHARS[Math.floor(Math.random() * SEED_CHARS.length)];
  }
  return out;
}

function encodeRoundChar(rounds: number): string {
  if (rounds === 10) return 'A';
  if (rounds === 1 || rounds === 3 || rounds === 5 || rounds === 6 || rounds === 8) {
    return String(rounds);
  }
  return '5';
}

function decodeRoundChar(ch: string): number | null {
  if (ch === 'A') return 10;
  const n = Number(ch);
  if (n === 1 || n === 3 || n === 5 || n === 6 || n === 8) return n;
  return null;
}

export function encodeOfflineSyncCode(
  wordLen: 5 | 6,
  rounds: number,
  durationSec: number,
  seed4: string
): string {
  const durIdx = Math.max(
    0,
    DURATION_OPTIONS.findIndex((d) => d.sec === durationSec)
  );
  const cleanSeed = seed4
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 4)
    .padEnd(4, 'X');
  return `${wordLen}${encodeRoundChar(rounds)}${durIdx}-${cleanSeed}`;
}

export function decodeOfflineSyncCode(raw: string): {
  wordLen: 5 | 6;
  rounds: number;
  durationSec: number;
  normalizedCode: string;
} | null {
  const compact = raw.toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (compact.length !== 7) return null;

  const lenDigit = compact[0];
  const roundChar = compact[1];
  const durDigit = compact[2];
  const seed4 = compact.slice(3, 7);

  if (lenDigit !== '5' && lenDigit !== '6') return null;
  const rounds = decodeRoundChar(roundChar);
  if (!rounds) return null;
  const durIdx = Number(durDigit);
  if (!Number.isInteger(durIdx) || durIdx < 0 || durIdx >= DURATION_OPTIONS.length) {
    return null;
  }

  return {
    wordLen: lenDigit === '6' ? 6 : 5,
    rounds,
    durationSec: DURATION_OPTIONS[durIdx].sec,
    normalizedCode: `${lenDigit}${roundChar}${durDigit}-${seed4}`,
  };
}

export function calculateDuelAttemptScore(attemptsUsed: number, maxAttempts = MAX_DUEL_GUESSES): number {
  return Math.max(1, maxAttempts - attemptsUsed + 1);
}

function formatDurationLabel(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return s === 0 ? `${m} daqiqa` : `${m}:${String(s).padStart(2, '0')}`;
}

type TogetherPhase = 'VARIANT_PICK' | 'CONNECTION_PICK' | 'SETUP' | 'PLAYING' | 'FINISHED';
type AiDifficulty = 'easy' | 'medium' | 'hard';

const AI_DIFFICULTY_META: Record<
  AiDifficulty,
  { labelUz: string; descUz: string; intervalMs: number; chance: number; minPts: number; spanPts: number }
> = {
  easy: {
    labelUz: 'Oson',
    descUz: 'Sekinroq javob · 1–2 ball',
    intervalMs: 9500,
    chance: 0.28,
    minPts: 1,
    spanPts: 2,
  },
  medium: {
    labelUz: 'Oʻrta',
    descUz: 'Muvozanatli raqib · 1–4 ball',
    intervalMs: 7500,
    chance: 0.36,
    minPts: 1,
    spanPts: 4,
  },
  hard: {
    labelUz: 'Qiyin',
    descUz: 'Tezkor usta · 2–5 ball',
    intervalMs: 5500,
    chance: 0.48,
    minPts: 2,
    spanPts: 4,
  },
};

export const TogetherMode: React.FC<TogetherModeProps> = ({
  profile,
  isSignedIn,
  onSignIn,
  onBack,
  onUsePowerup,
  onFinishDuel,
}) => {
  const [selectedVariant, setSelectedVariant] = useState<DuelVariant | null>(null);
  const [connectionMode, setConnectionMode] = useState<DuelConnectionType | null>(null);
  const [phase, setPhase] = useState<TogetherPhase>('VARIANT_PICK');

  // Duel settings configured in SETUP screen
  const [duelWordLen, setDuelWordLen] = useState<5 | 6>(5);
  const [customRounds, setCustomRounds] = useState<number>(1);
  const [customDurationSec, setCustomDurationSec] = useState<number>(120);
  const [aiDifficulty, setAiDifficulty] = useState<AiDifficulty>('medium');

  // Online & 2-Phone Offline Sync Code state
  const [inviteInput, setInviteInput] = useState<string>('');
  const [offlineSeed4, setOfflineSeed4] = useState<string>(() => generateSeed4());
  const [offlineJoinInput, setOfflineJoinInput] = useState<string>('');
  const [activeOfflineCode, setActiveOfflineCode] = useState<string>('');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [lobbyError, setLobbyError] = useState<string>('');
  const [lobbyBusy, setLobbyBusy] = useState<boolean>(false);
  const [onlineRoom, setOnlineRoom] = useState<DuelRoom | null>(null);

  // Active match state
  const [words, setWords] = useState<string[]>([]);
  const [roundIdx, setRoundIdx] = useState<number>(0);
  const [guesses, setGuesses] = useState<string[]>([]);
  const [currentGuess, setCurrentGuess] = useState<string>('');
  const [timeLeft, setTimeLeft] = useState<number>(120);
  const [turnTimeLeft, setTurnTimeLeft] = useState<number>(TURN_DURATION_SECONDS);
  const [lastRoundPoints, setLastRoundPoints] = useState<number | null>(null);
  const [paused, setPaused] = useState<boolean>(false);
  const [shakeRow, setShakeRow] = useState<boolean>(false);
  const [toast, setToast] = useState<string>('');
  const [revealedHintCols, setRevealedHintCols] = useState<Record<number, string>>({});
  const [rivalStunnedUntil, setRivalStunnedUntil] = useState<number>(0);

  // Scores
  const [myScore, setMyScore] = useState<number>(0);
  const [mySolved, setMySolved] = useState<number>(0);
  const [allyScore, setAllyScore] = useState<number>(0);
  const [rivalScore, setRivalScore] = useState<number>(0);

  const [victoryReward, setVictoryReward] = useState<VictoryReward | null>(null);
  const finishHandledRef = useRef<boolean>(false);
  const roundTransitionRef = useRef<boolean>(false);

  const hostOfflineSyncCode = useMemo(
    () => encodeOfflineSyncCode(duelWordLen, customRounds, customDurationSec, offlineSeed4),
    [customDurationSec, customRounds, duelWordLen, offlineSeed4]
  );

  const parsedOfflineJoin = useMemo(
    () => decodeOfflineSyncCode(offlineJoinInput),
    [offlineJoinInput]
  );

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast((prev) => (prev === msg ? '' : prev)), 2200);
  }, []);

  // Subscribe to online room updates
  useEffect(() => {
    if (connectionMode !== 'online' || !onlineRoom?.inviteCode) return;
    const unsub = subscribeToDuelRoom(onlineRoom.inviteCode, (updatedRoom) => {
      setOnlineRoom(updatedRoom);
      if (updatedRoom.status === 'active' && phase === 'SETUP') {
        setWords(updatedRoom.words);
        setTimeLeft(updatedRoom.durationSeconds);
        setTurnTimeLeft(TURN_DURATION_SECONDS);
        setLastRoundPoints(null);
        setRoundIdx(0);
        setGuesses([]);
        setCurrentGuess('');
        setMyScore(0);
        setMySolved(0);
        finishHandledRef.current = false;
        roundTransitionRef.current = false;
        setPhase('PLAYING');
      }
      if (updatedRoom.status === 'finished' && phase === 'PLAYING' && !finishHandledRef.current) {
        finishHandledRef.current = true;
        setPhase('FINISHED');
      }
    });
    return () => unsub();
  }, [connectionMode, onlineRoom?.inviteCode, phase]);

  // Compute live online scores from room
  const onlineScores = useMemo(() => {
    if (!onlineRoom) return null;
    const myUid = auth.currentUser?.uid || profile.uid;
    const players = Object.values(onlineRoom.playerStates);
    const me = players.find((p) => p.uid === myUid);
    const blueTotal = players.filter((p) => p.team === 'blue').reduce((s, p) => s + p.score, 0);
    const redTotal = players.filter((p) => p.team === 'red').reduce((s, p) => s + p.score, 0);
    const rival = players.find((p) => p.uid !== myUid);
    const scrambledNow = Boolean(me?.scrambleUntilMs && me.scrambleUntilMs > Date.now());
    return { me, rival, blueTotal, redTotal, scrambledNow, players };
  }, [onlineRoom, profile.uid]);

  const finishMatch = useCallback(
    (finalMyTotal: number, finalRivalTotal: number, customSummary?: string) => {
      if (finishHandledRef.current) return;
      finishHandledRef.current = true;
      setPhase('FINISHED');

      const meta = selectedVariant ? DUEL_VARIANT_META[selectedVariant] : DUEL_VARIANT_META.classic_duel;
      const isWin = finalMyTotal > finalRivalTotal;
      const isDraw = finalMyTotal === finalRivalTotal;
      const rewardUzc = isWin ? meta.rewardWinUzc : isDraw ? Math.round(meta.rewardWinUzc * 0.5) : 35;
      const rewardXp = isWin ? 90 : isDraw ? 55 : 30;

      if (isWin) {
        soundFx.victory(profile.settings.sound);
        triggerHaptic(profile.settings.vibration, [40, 40, 70]);
      } else {
        soundFx.coin(profile.settings.sound);
      }

      onFinishDuel(isWin, rewardUzc, rewardXp);
      setVictoryReward({
        titleUz: isWin ? 'Duel Yakunlandi!' : isDraw ? 'Durrang!' : 'Duel Yakunlandi',
        subtitleUz:
          customSummary ||
          `Hisob: ${finalMyTotal} — ${finalRivalTotal}. ${
            isWin ? 'Raqibingizdan ustun keldingiz!' : isDraw ? 'Kuchlar teng keldi!' : 'Keyingi dueda albatta yutasiz!'
          }`,
        uzc: rewardUzc,
        xp: rewardXp,
        isWin,
      });
    },
    [onFinishDuel, profile.settings.sound, profile.settings.vibration, selectedVariant]
  );

  // Match & per-turn countdown timers during active play
  useEffect(() => {
    if (phase !== 'PLAYING' || paused) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev <= 1 ? 0 : prev - 1));
      setTurnTimeLeft((prev) => {
        if (roundTransitionRef.current) return prev;
        return prev <= 1 ? 0 : prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [phase, paused]);

  // Trigger finish when match timer hits 0
  useEffect(() => {
    if (phase !== 'PLAYING' || timeLeft > 0) return;
    if (connectionMode === 'online' && onlineRoom && onlineScores) {
      const myTeam = onlineScores.me?.team || 'blue';
      const mySide = myTeam === 'blue' ? onlineScores.blueTotal : onlineScores.redTotal;
      const otherSide = myTeam === 'blue' ? onlineScores.redTotal : onlineScores.blueTotal;
      finishMatch(mySide, otherSide);
    } else if (connectionMode === 'offline_code') {
      finishMatch(
        myScore,
        0,
        `Oflayn kod: ${activeOfflineCode}. Yakuniy ballingiz: ${myScore} ball! 2-telefon natijasi bilan solishtiring.`
      );
    } else {
      const myTotal = myScore + (selectedVariant === 'team_duel' ? allyScore : 0);
      finishMatch(myTotal, rivalScore);
    }
  }, [
    activeOfflineCode,
    allyScore,
    connectionMode,
    finishMatch,
    myScore,
    onlineRoom,
    onlineScores,
    phase,
    rivalScore,
    selectedVariant,
    timeLeft,
  ]);

  // AI Bot opponent (adaptive difficulty + AI teammate in Team Duel)
  useEffect(() => {
    if (phase !== 'PLAYING' || paused || connectionMode !== 'bot') return;
    const cfg = AI_DIFFICULTY_META[aiDifficulty];
    const interval = setInterval(() => {
      if (Date.now() < rivalStunnedUntil) return;

      const effectiveChance = selectedVariant === 'team_duel' ? cfg.chance + 0.06 : cfg.chance;
      if (Math.random() < effectiveChance) {
        const botPoints = cfg.minPts + Math.floor(Math.random() * cfg.spanPts);
        setRivalScore((prev) => prev + botPoints);
      }

      if (selectedVariant === 'team_duel' && Math.random() < 0.34) {
        const allyPoints = 1 + Math.floor(Math.random() * 3);
        setAllyScore((prev) => prev + allyPoints);
      }
    }, cfg.intervalMs);
    return () => clearInterval(interval);
  }, [aiDifficulty, connectionMode, paused, phase, rivalStunnedUntil, selectedVariant]);

  const startAiMatch = () => {
    if (!selectedVariant) return;
    const seed = generateSeed4();
    const pickedWords = getDuelWordsFromSeed(seed, customRounds, duelWordLen);

    setConnectionMode('bot');
    setWords(pickedWords);
    setRoundIdx(0);
    setGuesses([]);
    setCurrentGuess('');
    setTimeLeft(customDurationSec);
    setTurnTimeLeft(TURN_DURATION_SECONDS);
    setLastRoundPoints(null);
    setMyScore(0);
    setMySolved(0);
    setAllyScore(0);
    setRivalScore(0);
    setRevealedHintCols({});
    setRivalStunnedUntil(0);
    setPaused(false);
    setVictoryReward(null);
    finishHandledRef.current = false;
    roundTransitionRef.current = false;
    setPhase('PLAYING');
  };

  const startOfflineSyncedMatch = (syncCodeToUse: string) => {
    if (!selectedVariant) return;
    const parsed = decodeOfflineSyncCode(syncCodeToUse);
    if (!parsed) {
      setLobbyError('Kod notoʻgʻri! Namuna: 511-K7M4');
      return;
    }

    const pickedWords = getDuelWordsFromSeed(
      parsed.normalizedCode,
      parsed.rounds,
      parsed.wordLen
    );

    setDuelWordLen(parsed.wordLen);
    setCustomRounds(parsed.rounds);
    setCustomDurationSec(parsed.durationSec);
    setActiveOfflineCode(parsed.normalizedCode);
    setConnectionMode('offline_code');
    setWords(pickedWords);
    setRoundIdx(0);
    setGuesses([]);
    setCurrentGuess('');
    setTimeLeft(parsed.durationSec);
    setTurnTimeLeft(TURN_DURATION_SECONDS);
    setLastRoundPoints(null);
    setMyScore(0);
    setMySolved(0);
    setAllyScore(0);
    setRivalScore(0);
    setRevealedHintCols({});
    setRivalStunnedUntil(0);
    setPaused(false);
    setVictoryReward(null);
    finishHandledRef.current = false;
    roundTransitionRef.current = false;
    setPhase('PLAYING');
  };

  const handleCreateOnline = async () => {
    if (!selectedVariant) return;
    setLobbyError('');
    setLobbyBusy(true);
    try {
      if (!isSignedIn) {
        await onSignIn();
      }
      const room = await createOnlineDuelRoom(
        selectedVariant,
        profile.displayName,
        profile.avatarId,
        {
          wordLen: duelWordLen,
          totalRounds: customRounds,
          durationSeconds: customDurationSec,
        }
      );
      setOnlineRoom(room);
    } catch (err) {
      setLobbyError(err instanceof Error ? err.message : 'Xona yaratishda xatolik');
    } finally {
      setLobbyBusy(false);
    }
  };

  const handleJoinOnline = async () => {
    setLobbyError('');
    setLobbyBusy(true);
    try {
      if (!isSignedIn) {
        await onSignIn();
      }
      const room = await joinOnlineDuelRoom(inviteInput, profile.displayName, profile.avatarId);
      setOnlineRoom(room);
      setSelectedVariant(room.variant);
    } catch (err) {
      setLobbyError(err instanceof Error ? err.message : 'Xonaga qoʻshilishda xatolik');
    } finally {
      setLobbyBusy(false);
    }
  };

  const handleStartOnlineHost = async () => {
    if (!onlineRoom) return;
    setLobbyBusy(true);
    try {
      await startOnlineDuelRoom(onlineRoom.inviteCode);
    } catch (err) {
      setLobbyError(err instanceof Error ? err.message : 'Boshlashda xatolik');
    } finally {
      setLobbyBusy(false);
    }
  };

  const currentTarget = words[roundIdx] || (duelWordLen === 6 ? 'PLANET' : 'APPLE');
  const activeWordLen: 5 | 6 = currentTarget.length === 6 ? 6 : 5;
  const activeTotalRounds = words.length || customRounds;

  const wordValidation = useMemo(() => {
    if (phase !== 'PLAYING' || paused) return 'empty' as const;
    return validateWordRealtime(currentGuess, activeWordLen);
  }, [activeWordLen, currentGuess, paused, phase]);

  const isInvalidRealtime =
    wordValidation === 'invalid_prefix' || wordValidation === 'invalid_word';
  const isValidFullWord = wordValidation === 'valid_word';

  const keyStates = useMemo(() => {
    const map: Record<string, LetterState> = {};
    const rank: Record<LetterState, number> = {
      empty: 0,
      tbd: 1,
      absent: 2,
      present: 3,
      correct: 4,
    };
    guesses.forEach((guess) => {
      const evals = evaluateWordleGuess(guess, currentTarget);
      guess.split('').forEach((ch, idx) => {
        const next = evals[idx];
        if (!map[ch] || rank[next] > rank[map[ch]]) {
          map[ch] = next;
        }
      });
    });
    return map;
  }, [guesses, currentTarget]);

  const handleKey = useCallback(
    (letter: string) => {
      if (phase !== 'PLAYING' || paused || currentGuess.length >= activeWordLen) return;
      soundFx.key(profile.settings.sound);
      triggerHaptic(profile.settings.vibration, 8);
      setCurrentGuess((prev) => prev + letter);
    },
    [activeWordLen, currentGuess.length, paused, phase, profile.settings.sound, profile.settings.vibration]
  );

  const handleBackspace = useCallback(() => {
    if (phase !== 'PLAYING' || paused || currentGuess.length === 0) return;
    soundFx.delete(profile.settings.sound);
    setCurrentGuess((prev) => prev.slice(0, -1));
  }, [currentGuess.length, paused, phase, profile.settings.sound]);

  const advanceRoundOrFinish = useCallback(
    async (gainedPoints: number, solvedThisRound: boolean) => {
      const nextRound = roundIdx + 1;
      const totalRounds = words.length;
      setLastRoundPoints(gainedPoints);

      const nextScore = myScore + gainedPoints;
      const nextSolved = mySolved + (solvedThisRound ? 1 : 0);
      setMyScore(nextScore);
      setMySolved(nextSolved);

      if (connectionMode === 'online' && onlineRoom && auth.currentUser) {
        const myUid = auth.currentUser.uid;
        const existingState = onlineRoom.playerStates[myUid];
        const updatedMyState: DuelPlayerState = {
          ...(existingState || {
            uid: myUid,
            displayName: profile.displayName,
            avatarId: profile.avatarId,
            team: 'blue',
          }),
          score: nextScore,
          roundIndex: nextRound,
          solvedCount: nextSolved,
          finished: nextRound >= totalRounds,
        };

        const isLast = nextRound >= totalRounds;
        let finishPayload: { status: 'finished'; winnerTeam: string } | undefined;
        if (isLast) {
          const allStates = { ...onlineRoom.playerStates, [myUid]: updatedMyState };
          const blueSum = Object.values(allStates)
            .filter((p) => p.team === 'blue')
            .reduce((s, p) => s + p.score, 0);
          const redSum = Object.values(allStates)
            .filter((p) => p.team === 'red')
            .reduce((s, p) => s + p.score, 0);
          finishPayload = {
            status: 'finished',
            winnerTeam: blueSum > redSum ? 'blue' : redSum > blueSum ? 'red' : 'draw',
          };
        }

        updateOnlineDuelProgress(onlineRoom, updatedMyState, undefined, finishPayload).catch(() => {});

        if (isLast) {
          const myTeam = updatedMyState.team;
          const allStates = { ...onlineRoom.playerStates, [myUid]: updatedMyState };
          const blueSum = Object.values(allStates)
            .filter((p) => p.team === 'blue')
            .reduce((s, p) => s + p.score, 0);
          const redSum = Object.values(allStates)
            .filter((p) => p.team === 'red')
            .reduce((s, p) => s + p.score, 0);
          const mySide = myTeam === 'blue' ? blueSum : redSum;
          const otherSide = myTeam === 'blue' ? redSum : blueSum;
          finishMatch(mySide, otherSide);
          return;
        }
      } else if (nextRound >= totalRounds) {
        if (connectionMode === 'offline_code') {
          finishMatch(
            nextScore,
            0,
            `Kod: ${activeOfflineCode}. Sizning ballingiz: ${nextScore} ball! 2-telefon natijasi bilan solishtiring.`
          );
        } else {
          const myTotal = nextScore + (selectedVariant === 'team_duel' ? allyScore : 0);
          finishMatch(myTotal, rivalScore);
        }
        return;
      }

      setRoundIdx(nextRound);
      setGuesses([]);
      setCurrentGuess('');
      setRevealedHintCols({});
      setTurnTimeLeft(TURN_DURATION_SECONDS);
      roundTransitionRef.current = false;
    },
    [
      activeOfflineCode,
      allyScore,
      connectionMode,
      finishMatch,
      myScore,
      mySolved,
      onlineRoom,
      profile.avatarId,
      profile.displayName,
      rivalScore,
      roundIdx,
      selectedVariant,
      words.length,
    ]
  );

  // Per-turn countdown expiration
  useEffect(() => {
    if (
      phase !== 'PLAYING' ||
      paused ||
      timeLeft <= 0 ||
      turnTimeLeft > 0 ||
      roundTransitionRef.current ||
      finishHandledRef.current
    ) {
      return;
    }
    roundTransitionRef.current = true;
    soundFx.error(profile.settings.sound);
    showToast(`Navbat vaqti tugadi! Soʻz: ${currentTarget} (0 ball)`);
    const timer = setTimeout(() => {
      advanceRoundOrFinish(0, false);
    }, 650);
    return () => clearTimeout(timer);
  }, [advanceRoundOrFinish, currentTarget, paused, phase, profile.settings.sound, showToast, timeLeft, turnTimeLeft]);

  const handleEnter = useCallback(() => {
    if (phase !== 'PLAYING' || paused || roundTransitionRef.current) return;
    if (currentGuess.length < activeWordLen) {
      soundFx.error(profile.settings.sound);
      setShakeRow(true);
      setTimeout(() => setShakeRow(false), 320);
      showToast(`${activeWordLen} ta harf kiriting!`);
      return;
    }
    const validDict = activeWordLen === 6 ? WORDS_6_VALID : WORDS_5_VALID;
    if (!validDict.has(currentGuess)) {
      soundFx.error(profile.settings.sound);
      setShakeRow(true);
      setTimeout(() => setShakeRow(false), 320);
      return;
    }

    const nextGuesses = [...guesses, currentGuess];
    setGuesses(nextGuesses);
    setCurrentGuess('');
    for (let i = 0; i < activeWordLen; i++) {
      soundFx.flip(profile.settings.sound, i);
    }

    if (currentGuess === currentTarget) {
      roundTransitionRef.current = true;
      const attemptsUsed = nextGuesses.length;
      const points = calculateDuelAttemptScore(attemptsUsed, MAX_DUEL_GUESSES);
      soundFx.match(profile.settings.sound);
      showToast(`Toʻgʻri (${attemptsUsed}-urinish)! +${points} ball`);
      setTimeout(() => {
        advanceRoundOrFinish(points, true);
      }, 480);
    } else if (nextGuesses.length >= MAX_DUEL_GUESSES) {
      roundTransitionRef.current = true;
      soundFx.error(profile.settings.sound);
      showToast(`Soʻz: ${currentTarget} (0 ball)`);
      setTimeout(() => {
        advanceRoundOrFinish(0, false);
      }, 720);
    }
  }, [
    activeWordLen,
    advanceRoundOrFinish,
    currentGuess,
    currentTarget,
    guesses,
    paused,
    phase,
    profile.settings.sound,
    showToast,
  ]);

  useEffect(() => {
    if (phase !== 'PLAYING' || paused) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.key === 'Enter') {
        e.preventDefault();
        handleEnter();
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleBackspace();
      } else if (/^[a-zA-Z]$/.test(e.key)) {
        e.preventDefault();
        handleKey(e.key.toUpperCase());
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleBackspace, handleEnter, handleKey, paused, phase]);

  // Battle Duel Power-ups
  const handlePowerup = (key: 'revealLetter' | 'freezeTime' | 'scrambleRival') => {
    if (phase !== 'PLAYING' || selectedVariant !== 'battle_duel') return;
    if (!onUsePowerup(key)) {
      showToast('Bu kuchaytirgich tugagan! Doʻkondan oling');
      return;
    }
    soundFx.powerup(profile.settings.sound);
    triggerHaptic(profile.settings.vibration, 25);

    if (key === 'revealLetter') {
      const indices = Array.from({ length: activeWordLen }, (_, i) => i);
      const unrevealed = indices.filter((i) => !revealedHintCols[i]);
      if (unrevealed.length > 0) {
        const pick = unrevealed[Math.floor(Math.random() * unrevealed.length)];
        setRevealedHintCols((prev) => ({ ...prev, [pick]: currentTarget[pick] }));
        showToast(`${pick + 1}-harf ochildi: ${currentTarget[pick]}`);
      }
    } else if (key === 'freezeTime') {
      setTimeLeft((prev) => prev + 15);
      setTurnTimeLeft((prev) => prev + 15);
      showToast('+15 soniya qoʻshildi!');
    } else if (key === 'scrambleRival') {
      if (connectionMode === 'online' && onlineRoom && onlineScores?.rival && auth.currentUser) {
        const myUid = auth.currentUser.uid;
        const myState = onlineRoom.playerStates[myUid];
        const rivalSt = onlineScores.rival;
        updateOnlineDuelProgress(onlineRoom, myState, {
          [rivalSt.uid]: { ...rivalSt, scrambleUntilMs: Date.now() + 6500 },
        }).catch(() => {});
        showToast('Raqib klaviaturasi 6 soniyaga chalgʻitildi!');
      } else {
        setRivalStunnedUntil(Date.now() + 6500);
        showToast('Raqib bot 6 soniyaga muzlatildi!');
      }
    }
  };

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  const copyCode = (code: string) => {
    navigator.clipboard?.writeText(code).catch(() => {});
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 1800);
  };

  // ==================== SCREEN 1: DUEL VARIANT PICKER ====================
  if (phase === 'VARIANT_PICK') {
    return (
      <div className="min-h-[100dvh] w-full flex flex-col justify-between bg-gradient-to-b from-sky-500 via-blue-600 to-indigo-700 dark:from-slate-900 dark:via-slate-950 dark:to-black text-white">
        <header className="w-full max-w-4xl mx-auto px-3.5 pt-4 pb-2 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={onBack}
            className="w-10 h-10 rounded-xl bg-black/20 hover:bg-black/30 border border-white/20 flex items-center justify-center cursor-pointer shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="px-4 py-2 rounded-2xl bg-gradient-to-b from-amber-200 to-amber-400 text-amber-950 border-b-4 border-amber-600 shadow-lg flex items-center gap-2">
            <Swords className="w-5 h-5 text-rose-600 shrink-0" />
            <h1 className="font-display font-bold text-lg leading-none">TOGETHER</h1>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-black/25 border border-white/20 shrink-0">
            <UzcCoinIcon className="w-4 h-4" />
            <span className="font-mono-num text-xs sm:text-sm font-bold text-amber-200">{profile.uzc}</span>
          </div>
        </header>

        <main className="flex-1 w-full max-w-4xl mx-auto px-4 py-5 flex items-center">
          <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-4 items-stretch">
            {(
              [
                {
                  id: 'classic_duel' as DuelVariant,
                  gradient: 'from-sky-400 via-blue-500 to-blue-700',
                  border: 'border-sky-200/60',
                  avatars: ['boy_blue', 'girl_amber'] as const,
                },
                {
                  id: 'battle_duel' as DuelVariant,
                  gradient: 'from-violet-500 via-purple-600 to-indigo-800',
                  border: 'border-purple-200/60',
                  avatars: ['cool_shades', 'crown_pro'] as const,
                },
                {
                  id: 'team_duel' as DuelVariant,
                  gradient: 'from-emerald-400 via-green-600 to-teal-800',
                  border: 'border-emerald-200/60',
                  avatars: ['boy_blue', 'scholar_owl'] as const,
                },
              ]
            ).map((card) => {
              const meta = DUEL_VARIANT_META[card.id];
              return (
                <div
                  key={card.id}
                  className={`rounded-3xl bg-gradient-to-b ${card.gradient} border-2 ${card.border} p-5 flex flex-col justify-between shadow-xl`}
                >
                  <div>
                    <div className="text-center mb-3">
                      <h2 className="font-display font-bold text-2xl drop-shadow-sm">{meta.titleUz}</h2>
                      <p className="text-xs text-white/90 font-semibold mt-0.5">{meta.subtitleUz}</p>
                    </div>

                    <div className="flex items-center justify-center gap-3 my-4">
                      <PlayerAvatarSvg avatarId={card.avatars[0]} className="w-14 h-14 drop-shadow-lg" />
                      <span className="font-display font-bold text-2xl text-amber-300 drop-shadow-[0_2px_0_rgba(180,83,9,1)]">
                        VS
                      </span>
                      <PlayerAvatarSvg avatarId={card.avatars[1]} className="w-14 h-14 drop-shadow-lg" />
                    </div>

                    <div className="text-center text-xs font-bold text-amber-100 mb-4 flex items-center justify-center gap-1.5">
                      <UzcCoinIcon className="w-4 h-4" />
                      +{meta.rewardWinUzc} UZC
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      soundFx.key(profile.settings.sound);
                      setSelectedVariant(card.id);
                      setCustomRounds(1);
                      setCustomDurationSec(meta.durationSeconds);
                      setLobbyError('');
                      setOnlineRoom(null);
                      setConnectionMode(null);
                      setPhase('CONNECTION_PICK');
                    }}
                    className="w-full py-3.5 rounded-2xl bg-gradient-to-b from-amber-300 to-amber-500 hover:from-amber-200 hover:to-amber-400 text-amber-950 font-display font-bold text-base border-b-4 border-amber-700 active:translate-y-0.5 transition-transform flex items-center justify-center gap-2 cursor-pointer"
                  >
                    Tanlash
                    <Play className="w-4 h-4 fill-current" />
                  </button>
                </div>
              );
            })}
          </div>
        </main>
      </div>
    );
  }

  // ==================== SCREEN 2: ADAPTIVE 3-OPTION CONNECTION MENU (ONLINE / AI / OFFLINE) ====================
  if (phase === 'CONNECTION_PICK' && selectedVariant) {
    const meta = DUEL_VARIANT_META[selectedVariant];

    return (
      <div className="min-h-[100dvh] w-full flex flex-col bg-gradient-to-b from-sky-500 via-blue-600 to-indigo-700 dark:from-slate-900 dark:via-slate-950 dark:to-black text-white">
        <header className="w-full max-w-3xl mx-auto px-4 pt-4 pb-2 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => {
              setPhase('VARIANT_PICK');
              setConnectionMode(null);
            }}
            aria-label="Orqaga"
            className="w-10 h-10 rounded-xl bg-black/20 hover:bg-black/30 border border-white/20 flex items-center justify-center cursor-pointer shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="text-center">
            <h1 className="font-display font-bold text-2xl drop-shadow-sm">{meta.titleUz}</h1>
            <p className="text-xs text-sky-100/90 font-semibold">Oʻyin usulini tanlang</p>
          </div>

          <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-black/25 border border-white/20 shrink-0">
            <UzcCoinIcon className="w-4 h-4" />
            <span className="font-mono-num text-xs font-bold text-amber-200">{profile.uzc}</span>
          </div>
        </header>

        <main className="flex-1 w-full max-w-3xl mx-auto px-4 sm:px-6 py-6 flex items-center">
          <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-4 items-stretch">
            {/* Online Card */}
            <button
              type="button"
              onClick={() => {
                soundFx.key(profile.settings.sound);
                setConnectionMode('online');
                setLobbyError('');
                setOnlineRoom(null);
                setPhase('SETUP');
              }}
              className="w-full p-5 rounded-3xl bg-gradient-to-b from-emerald-400 to-emerald-600 hover:from-emerald-300 hover:to-emerald-500 text-white border-b-[6px] border-emerald-800 shadow-xl flex md:flex-col items-center md:justify-between gap-4 text-left md:text-center active:translate-y-1 transition-transform cursor-pointer"
            >
              <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
                <Globe className="w-8 h-8 md:w-9 md:h-9" />
              </div>
              <div className="flex-1 md:flex-initial">
                <div className="font-display font-bold text-2xl tracking-wide">ONLINE</div>
                <p className="text-xs text-emerald-50/95 font-semibold mt-1">
                  Real-vaqt xona kodi bilan doʻstlarga qarshi
                </p>
              </div>
              <span className="px-3.5 py-2 rounded-xl bg-black/20 font-display font-bold text-xs flex items-center gap-1 shrink-0 md:w-full md:justify-center">
                Tanlash
                <Play className="w-3.5 h-3.5 fill-current" />
              </span>
            </button>

            {/* AI Card */}
            <button
              type="button"
              onClick={() => {
                soundFx.key(profile.settings.sound);
                setConnectionMode('bot');
                setLobbyError('');
                setOnlineRoom(null);
                setPhase('SETUP');
              }}
              className="w-full p-5 rounded-3xl bg-gradient-to-b from-sky-300 to-blue-500 hover:from-sky-200 hover:to-blue-400 text-slate-950 border-b-[6px] border-blue-800 shadow-xl flex md:flex-col items-center md:justify-between gap-4 text-left md:text-center active:translate-y-1 transition-transform cursor-pointer"
            >
              <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-white/40 flex items-center justify-center shrink-0">
                <Bot className="w-8 h-8 md:w-9 md:h-9 text-blue-950" />
              </div>
              <div className="flex-1 md:flex-initial">
                <div className="font-display font-bold text-2xl tracking-wide">AI</div>
                <p className="text-xs text-blue-950/85 font-bold mt-1">
                  Oson, Oʻrta yoki Qiyin aqlli bot bilan duel
                </p>
              </div>
              <span className="px-3.5 py-2 rounded-xl bg-white/45 font-display font-bold text-xs flex items-center gap-1 shrink-0 md:w-full md:justify-center">
                Tanlash
                <Play className="w-3.5 h-3.5 fill-current" />
              </span>
            </button>

            {/* Offline Card */}
            <button
              type="button"
              onClick={() => {
                soundFx.key(profile.settings.sound);
                setConnectionMode('offline_code');
                setLobbyError('');
                setOnlineRoom(null);
                setPhase('SETUP');
              }}
              className="w-full p-5 rounded-3xl bg-gradient-to-b from-amber-300 to-amber-500 hover:from-amber-200 hover:to-amber-400 text-amber-950 border-b-[6px] border-amber-700 shadow-xl flex md:flex-col items-center md:justify-between gap-4 text-left md:text-center active:translate-y-1 transition-transform cursor-pointer"
            >
              <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-white/45 flex items-center justify-center shrink-0">
                <WifiOff className="w-8 h-8 md:w-9 md:h-9 text-amber-950" />
              </div>
              <div className="flex-1 md:flex-initial">
                <div className="font-display font-bold text-2xl tracking-wide">OFFLINE</div>
                <p className="text-xs text-amber-950/85 font-bold mt-1">
                  2 ta alohida telefonda kod bilan sinxron oʻyin
                </p>
              </div>
              <span className="px-3.5 py-2 rounded-xl bg-white/50 font-display font-bold text-xs flex items-center gap-1 shrink-0 md:w-full md:justify-center">
                Tanlash
                <Play className="w-3.5 h-3.5 fill-current" />
              </span>
            </button>
          </div>
        </main>
      </div>
    );
  }

  // ==================== SCREEN 3: ADAPTIVE MODE-SPECIFIC SETUP & SOZLASH ====================
  if (phase === 'SETUP' && selectedVariant && connectionMode) {
    const meta = DUEL_VARIANT_META[selectedVariant];
    const modeLabel =
      connectionMode === 'online' ? 'Online' : connectionMode === 'bot' ? 'AI' : 'Offline';

    const settingsPanel = !onlineRoom && (
      <section className="rounded-3xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-b-4 border-sky-200 dark:border-slate-700 p-4 sm:p-5 shadow-xl space-y-3.5">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-sky-100 dark:bg-sky-500/20 flex items-center justify-center text-sky-600 dark:text-sky-300">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-display font-bold text-base leading-none">Sozlash</h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
              {duelWordLen} harf · {customRounds === 1 ? '1 (Yagona soʻz)' : `${customRounds} raund`} ·{' '}
              {formatDurationLabel(customDurationSec)}
            </p>
          </div>
        </div>

        {/* Word Length */}
        <div>
          <div className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5">
            Soʻz uzunligi
          </div>
          <div className="grid grid-cols-2 gap-2">
            {([5, 6] as const).map((len) => (
              <button
                key={len}
                type="button"
                onClick={() => setDuelWordLen(len)}
                className={`py-2.5 rounded-xl font-display font-bold text-sm border-b-4 transition-colors cursor-pointer ${
                  duelWordLen === len
                    ? 'bg-amber-400 text-amber-950 border-amber-600'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-700'
                }`}
              >
                {len} HARFLI
              </button>
            ))}
          </div>
        </div>

        {/* Rounds */}
        <div>
          <div className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5">
            Raundlar soni (1 = yagona soʻz)
          </div>
          <div className="grid grid-cols-6 gap-1.5">
            {ROUND_OPTIONS.map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setCustomRounds(r)}
                className={`py-2 rounded-xl font-mono-num text-xs font-bold border-b-4 transition-colors cursor-pointer ${
                  customRounds === r
                    ? 'bg-sky-500 text-white border-sky-700'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-700'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>

        {/* Timer */}
        <div>
          <div className="text-xs font-bold text-slate-600 dark:text-slate-300 mb-1.5">
            Umumiy vaqt
          </div>
          <div className="grid grid-cols-5 gap-1.5">
            {DURATION_OPTIONS.map((opt) => (
              <button
                key={opt.sec}
                type="button"
                onClick={() => setCustomDurationSec(opt.sec)}
                className={`py-2 rounded-xl text-xs font-bold border-b-4 transition-colors cursor-pointer whitespace-nowrap ${
                  customDurationSec === opt.sec
                    ? 'bg-emerald-500 text-white border-emerald-700'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-700'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      </section>
    );

    return (
      <div className="min-h-[100dvh] w-full flex flex-col bg-gradient-to-b from-sky-500 via-blue-600 to-indigo-700 dark:from-slate-900 dark:via-slate-950 dark:to-black text-white">
        <header className="w-full max-w-4xl mx-auto px-4 pt-4 pb-2 flex items-center justify-between">
          <button
            type="button"
            onClick={() => {
              setPhase('CONNECTION_PICK');
              setOnlineRoom(null);
              setLobbyError('');
            }}
            aria-label="Orqaga"
            className="w-10 h-10 rounded-xl bg-black/20 hover:bg-black/30 border border-white/20 flex items-center justify-center cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="text-center">
            <h1 className="font-display font-bold text-xl drop-shadow-sm">
              {meta.titleUz} · {modeLabel}
            </h1>
            <p className="text-xs text-sky-100">Moslashuvchan sozlama</p>
          </div>
          <div className="w-10" />
        </header>

        <main className="flex-1 w-full max-w-4xl mx-auto px-4 py-4 flex flex-col gap-4">
          {lobbyError && (
            <div className="px-4 py-2.5 rounded-2xl bg-rose-600 text-white text-xs font-bold shadow-lg">
              {lobbyError}
            </div>
          )}

          {/* MODE A: AI ADAPTIVE UI */}
          {connectionMode === 'bot' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
              {settingsPanel}

              <section className="rounded-3xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-b-4 border-sky-200 dark:border-slate-700 p-4 sm:p-5 shadow-xl space-y-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-500/20 flex items-center justify-center text-blue-600 dark:text-blue-300">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="font-display font-bold text-base leading-none">AI Raqib Darajasi</h2>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                      {AI_DIFFICULTY_META[aiDifficulty].descUz}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {(['easy', 'medium', 'hard'] as AiDifficulty[]).map((level) => (
                    <button
                      key={level}
                      type="button"
                      onClick={() => setAiDifficulty(level)}
                      className={`py-3 px-2 rounded-2xl font-display font-bold text-sm border-b-4 transition-colors cursor-pointer ${
                        aiDifficulty === level
                          ? 'bg-sky-500 text-white border-sky-700'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-300 dark:border-slate-700'
                      }`}
                    >
                      {AI_DIFFICULTY_META[level].labelUz}
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={startAiMatch}
                  className="w-full py-4 rounded-2xl bg-gradient-to-b from-amber-300 to-amber-500 hover:from-amber-200 hover:to-amber-400 text-amber-950 font-display font-bold text-lg border-b-4 border-amber-700 shadow-lg flex items-center justify-center gap-2 active:translate-y-0.5 transition-transform cursor-pointer"
                >
                  <Play className="w-5 h-5 fill-current" />
                  AI bilan Boshlash
                </button>
              </section>
            </div>
          )}

          {/* MODE B: ONLINE ADAPTIVE UI */}
          {connectionMode === 'online' && (
            <div className={`grid grid-cols-1 ${onlineRoom ? '' : 'md:grid-cols-2'} gap-4 items-start`}>
              {settingsPanel}

              <section className="rounded-3xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-b-4 border-emerald-200 dark:border-slate-700 p-4 sm:p-5 shadow-xl space-y-4">
                {onlineRoom ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl p-3.5 border border-emerald-200 dark:border-emerald-700/40">
                      <div>
                        <div className="text-xs font-bold text-emerald-700 dark:text-emerald-300">
                          Xona kodi:
                        </div>
                        <div className="font-mono-num font-bold text-3xl tracking-widest text-slate-900 dark:text-amber-300">
                          {onlineRoom.inviteCode}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => copyCode(onlineRoom.inviteCode)}
                        className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white text-xs font-bold flex items-center gap-1.5 border-b-2 border-emerald-700 cursor-pointer"
                      >
                        {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        {copiedCode ? 'Nusxalandi' : 'Nusxalash'}
                      </button>
                    </div>

                    <div className="space-y-2">
                      <div className="text-xs text-slate-600 dark:text-slate-300 font-bold">
                        Ishtirokchilar ({onlineRoom.participantIds.length}/{onlineRoom.maxPlayers}):
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {Object.values(onlineRoom.playerStates).map((p) => (
                          <div
                            key={p.uid}
                            className={`px-3 py-2 rounded-xl flex items-center gap-2 text-xs font-bold ${
                              p.team === 'blue'
                                ? 'bg-sky-100 dark:bg-blue-600/30 text-sky-900 dark:text-white border border-sky-300 dark:border-blue-400/40'
                                : 'bg-rose-100 dark:bg-rose-600/30 text-rose-900 dark:text-white border border-rose-300 dark:border-rose-400/40'
                            }`}
                          >
                            <PlayerAvatarSvg avatarId={p.avatarId} className="w-7 h-7" />
                            <span className="truncate">{p.displayName}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {onlineRoom.hostId === auth.currentUser?.uid ? (
                      <button
                        type="button"
                        disabled={lobbyBusy || onlineRoom.participantIds.length < 2}
                        onClick={handleStartOnlineHost}
                        className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-white font-display font-bold text-base border-b-4 border-emerald-700 cursor-pointer"
                      >
                        {onlineRoom.participantIds.length < 2
                          ? 'Raqib qoʻshilishini kutmoqda...'
                          : 'Duelni Boshlash!'}
                      </button>
                    ) : (
                      <div className="text-center text-xs text-emerald-700 dark:text-amber-200 font-bold py-2">
                        Xona egasi oʻyinni boshlashini kutmoqda...
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-500/20 flex items-center justify-center text-emerald-600 dark:text-emerald-300">
                        <Globe className="w-5 h-5" />
                      </div>
                      <div>
                        <h2 className="font-display font-bold text-base leading-none">Onlayn Xona</h2>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                          Xona yarating yoki doʻst kodini kiriting
                        </p>
                      </div>
                    </div>

                    {!isSignedIn && (
                      <button
                        type="button"
                        onClick={onSignIn}
                        className="w-full py-2.5 rounded-xl bg-amber-100 dark:bg-white text-slate-900 font-bold text-xs cursor-pointer"
                      >
                        Onlayn oʻynash uchun Google orqali kiring
                      </button>
                    )}

                    <button
                      type="button"
                      disabled={lobbyBusy}
                      onClick={handleCreateOnline}
                      className="w-full py-3.5 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-white font-display font-bold text-base border-b-4 border-emerald-700 cursor-pointer disabled:opacity-50"
                    >
                      Yangi xona yaratish
                    </button>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        maxLength={6}
                        value={inviteInput}
                        onChange={(e) => setInviteInput(e.target.value.toUpperCase())}
                        placeholder="KOD (WRD742)"
                        className="flex-1 px-3.5 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-white/20 font-mono-num text-sm uppercase tracking-wider text-slate-900 dark:text-white"
                      />
                      <button
                        type="button"
                        disabled={lobbyBusy || inviteInput.trim().length !== 6}
                        onClick={handleJoinOnline}
                        className="px-5 py-2.5 rounded-2xl bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-white font-display font-bold text-sm border-b-4 border-sky-700 cursor-pointer whitespace-nowrap"
                      >
                        Kirish
                      </button>
                    </div>
                  </div>
                )}
              </section>
            </div>
          )}

          {/* MODE C: OFFLINE ADAPTIVE 2-PHONE SYNC UI */}
          {connectionMode === 'offline_code' && (
            <div className="space-y-4">
              {settingsPanel}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {/* Phone 1: Create & Share Code */}
                <div className="rounded-3xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-b-4 border-amber-300 dark:border-slate-700 p-4 shadow-xl flex flex-col justify-between gap-3">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300 font-display font-bold text-sm">
                      <Smartphone className="w-4 h-4" />
                      1-telefon: Kod yaratish
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                      Ushbu kodni 2-telefonga ayting — ikkalangizda ham aynan bir xil{' '}
                      {customRounds === 1 ? 'yagona soʻz' : `${customRounds} ta soʻz`} chiqadi.
                    </p>
                    <div className="flex items-center gap-1.5">
                      <div className="flex-1 px-3 py-2.5 rounded-xl bg-amber-50 dark:bg-slate-800 border border-amber-300 dark:border-amber-400/40 font-mono-num font-bold text-lg tracking-wider text-center text-amber-950 dark:text-amber-200">
                        {hostOfflineSyncCode}
                      </div>
                      <button
                        type="button"
                        onClick={() => copyCode(hostOfflineSyncCode)}
                        aria-label="Kodni nusxalash"
                        className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
                      >
                        {copiedCode ? (
                          <Check className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => setOfflineSeed4(generateSeed4())}
                        aria-label="Yangi kod"
                        className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => startOfflineSyncedMatch(hostOfflineSyncCode)}
                    className="w-full py-3 rounded-2xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-display font-bold text-sm border-b-4 border-amber-600 cursor-pointer"
                  >
                    Boshlash
                  </button>
                </div>

                {/* Phone 2: Enter Friend's Sync Code */}
                <div className="rounded-3xl bg-white dark:bg-slate-900 text-slate-900 dark:text-white border-b-4 border-sky-300 dark:border-slate-700 p-4 shadow-xl flex flex-col justify-between gap-3">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sky-700 dark:text-sky-300 font-display font-bold text-sm">
                      <Smartphone className="w-4 h-4" />
                      2-telefon: Kod kiritish
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-snug">
                      Doʻstingiz telefonidagi kodni kiriting — sozlama va soʻz avtomatik moslanadi.
                    </p>
                    <input
                      type="text"
                      maxLength={8}
                      value={offlineJoinInput}
                      onChange={(e) => {
                        setLobbyError('');
                        setOfflineJoinInput(e.target.value.toUpperCase());
                      }}
                      placeholder="511-K7M4"
                      className="w-full px-3 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-white/20 font-mono-num text-base font-bold tracking-widest text-center text-slate-900 dark:text-white"
                    />
                    {parsedOfflineJoin && (
                      <div className="text-[11px] font-bold text-emerald-700 dark:text-emerald-300 text-center">
                        {parsedOfflineJoin.wordLen} harf ·{' '}
                        {parsedOfflineJoin.rounds === 1
                          ? '1 yagona soʻz'
                          : `${parsedOfflineJoin.rounds} raund`}{' '}
                        · {formatDurationLabel(parsedOfflineJoin.durationSec)}
                      </div>
                    )}
                  </div>

                  <button
                    type="button"
                    disabled={!parsedOfflineJoin}
                    onClick={() => startOfflineSyncedMatch(offlineJoinInput)}
                    className="w-full py-3 rounded-2xl bg-sky-500 hover:bg-sky-400 disabled:opacity-45 text-white font-display font-bold text-sm border-b-4 border-sky-700 cursor-pointer"
                  >
                    Kodni qoʻllash
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    );
  }

  // ==================== SCREEN 4: ACTIVE DUEL ARENA ====================
  const meta = selectedVariant ? DUEL_VARIANT_META[selectedVariant] : DUEL_VARIANT_META.classic_duel;
  const arenaBg =
    selectedVariant === 'battle_duel'
      ? 'from-violet-600 via-purple-700 to-indigo-900'
      : selectedVariant === 'team_duel'
      ? 'from-emerald-500 via-teal-600 to-green-800'
      : 'from-sky-500 via-blue-600 to-indigo-700';

  const leftLabel = selectedVariant === 'team_duel' ? 'Koʻk jamoa' : 'Siz';
  const rightLabel =
    connectionMode === 'offline_code'
      ? '2-telefon'
      : selectedVariant === 'team_duel'
      ? 'Qizil jamoa'
      : connectionMode === 'online'
      ? onlineScores?.rival?.displayName || 'Raqib'
      : `AI (${AI_DIFFICULTY_META[aiDifficulty].labelUz})`;

  const leftDisplayScore =
    connectionMode === 'online' && onlineScores
      ? onlineScores.me?.team === 'red'
        ? onlineScores.redTotal
        : onlineScores.blueTotal
      : myScore + (selectedVariant === 'team_duel' ? allyScore : 0);

  const rightDisplayScore =
    connectionMode === 'online' && onlineScores
      ? onlineScores.me?.team === 'red'
        ? onlineScores.blueTotal
        : onlineScores.redTotal
      : rivalScore;

  const isKeyboardScrambled = Boolean(connectionMode === 'online' && onlineScores?.scrambledNow);

  return (
    <div
      className={`min-h-[100dvh] w-full flex flex-col justify-between bg-gradient-to-b ${arenaBg} dark:from-slate-900 dark:via-slate-950 dark:to-black text-white`}
    >
      {/* Top Arena Header */}
      <header className="w-full max-w-2xl mx-auto px-4 pt-3 pb-1 flex items-center justify-between">
        <button
          type="button"
          onClick={() => {
            setPhase('VARIANT_PICK');
            setOnlineRoom(null);
          }}
          className="w-10 h-10 rounded-xl bg-black/20 hover:bg-black/30 border border-white/20 flex items-center justify-center cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <div className="font-display font-bold text-lg sm:text-xl drop-shadow-sm">{meta.titleUz}</div>
          <div className="text-[11px] text-white/90 font-semibold">
            {roundIdx + 1}/{activeTotalRounds} raund · {activeWordLen} harf
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-black/25 border border-white/20 font-mono-num text-sm font-bold flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-amber-300" />
            {formatTime(timeLeft)}
          </div>
          {connectionMode !== 'online' && (
            <button
              type="button"
              onClick={() => setPaused((p) => !p)}
              aria-label="Pauza"
              className="w-10 h-10 rounded-xl bg-black/20 hover:bg-black/30 border border-white/20 flex items-center justify-center cursor-pointer"
            >
              <Pause className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      {/* Scoreboard & Live Turn Progress */}
      <section className="w-full max-w-xl mx-auto px-4 my-1">
        <div className="rounded-2xl bg-black/25 border border-white/20 px-4 py-2 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <PlayerAvatarSvg avatarId={profile.avatarId} className="w-10 h-10 shrink-0" />
            <div className="min-w-0">
              <div className="text-xs text-sky-100 font-bold truncate">{leftLabel}</div>
              <div className="font-mono-num font-bold text-2xl leading-none">{leftDisplayScore}</div>
            </div>
          </div>

          <div className="flex flex-col items-center">
            <span className="font-display font-bold text-xl text-amber-300">VS</span>
            {connectionMode === 'offline_code' && (
              <span className="font-mono-num text-[10px] font-bold text-amber-100">
                {activeOfflineCode}
              </span>
            )}
            {connectionMode === 'online' && onlineScores?.rival && (
              <span className="font-mono-num text-[10px] font-bold text-sky-100">
                Raqib: {Math.min(activeTotalRounds, (onlineScores.rival.roundIndex || 0) + 1)}/{activeTotalRounds}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2.5 min-w-0 text-right">
            <div className="min-w-0">
              <div className="text-xs text-rose-100 font-bold truncate">{rightLabel}</div>
              <div className="font-mono-num font-bold text-2xl leading-none">
                {connectionMode === 'offline_code' ? '—' : rightDisplayScore}
              </div>
            </div>
            <PlayerAvatarSvg
              avatarId={selectedVariant === 'team_duel' ? 'scholar_owl' : 'cool_shades'}
              className="w-10 h-10 shrink-0"
            />
          </div>
        </div>

        {/* Attempt Points Badge, Round Dots & Turn Countdown */}
        <div className="mt-2 rounded-2xl bg-black/25 border border-white/15 px-3 py-2 space-y-1.5">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-lg bg-emerald-500/30 border border-emerald-300/50 font-mono-num font-bold text-[11px] text-white">
                Urinish {Math.min(MAX_DUEL_GUESSES, guesses.length + 1)}/{MAX_DUEL_GUESSES} → +
                {calculateDuelAttemptScore(
                  Math.min(MAX_DUEL_GUESSES, guesses.length + 1),
                  MAX_DUEL_GUESSES
                )}{' '}
                ball
              </span>
              {lastRoundPoints !== null && (
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-lg bg-amber-400/25 border border-amber-200/40 font-mono-num font-bold text-[11px] text-amber-100">
                  Oldingi: +{lastRoundPoints}
                </span>
              )}
            </div>

            <div
              className={`px-2.5 py-0.5 rounded-lg font-mono-num font-bold text-xs flex items-center gap-1 border ${
                turnTimeLeft <= 6
                  ? 'bg-rose-500/35 border-rose-300 text-rose-100 animate-pulse'
                  : turnTimeLeft <= 12
                  ? 'bg-amber-400/30 border-amber-200 text-amber-100'
                  : 'bg-sky-400/25 border-sky-200/50 text-white'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              {turnTimeLeft}s
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="h-1.5 rounded-full bg-white/20 overflow-hidden">
              <div
                style={{ width: `${Math.round(((roundIdx + 1) / activeTotalRounds) * 100)}%` }}
                className="h-full rounded-full bg-amber-300 transition-all duration-300"
              />
            </div>
            <div className="h-1.5 rounded-full bg-white/20 overflow-hidden">
              <div
                style={{
                  width: `${Math.min(100, Math.round((turnTimeLeft / TURN_DURATION_SECONDS) * 100))}%`,
                }}
                className={`h-full rounded-full transition-all duration-300 ${
                  turnTimeLeft <= 6
                    ? 'bg-rose-400'
                    : turnTimeLeft <= 12
                    ? 'bg-amber-300'
                    : 'bg-sky-300'
                }`}
              />
            </div>
          </div>

          <div className="flex items-center justify-center gap-1.5">
            {Array.from({ length: activeTotalRounds }).map((_, idx) => (
              <span
                key={idx}
                className={`h-1.5 rounded-full transition-all ${
                  idx < roundIdx
                    ? 'w-4 bg-amber-300'
                    : idx === roundIdx
                    ? 'w-6 bg-white'
                    : 'w-2 bg-white/30'
                }`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Battle Duel Powerups */}
      {selectedVariant === 'battle_duel' && (
        <div className="w-full max-w-xl mx-auto px-4 my-1 flex items-center justify-center gap-2">
          <button
            type="button"
            onClick={() => handlePowerup('revealLetter')}
            className="px-3 py-1.5 rounded-xl bg-amber-300 hover:bg-amber-200 text-amber-950 font-display font-bold text-xs border-b-2 border-amber-600 flex items-center gap-1 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            Harf ({profile.powerups.revealLetter})
          </button>
          <button
            type="button"
            onClick={() => handlePowerup('freezeTime')}
            className="px-3 py-1.5 rounded-xl bg-sky-300 hover:bg-sky-200 text-sky-950 font-display font-bold text-xs border-b-2 border-sky-600 flex items-center gap-1 cursor-pointer"
          >
            <Clock className="w-3.5 h-3.5" />
            +15s ({profile.powerups.freezeTime})
          </button>
          <button
            type="button"
            onClick={() => handlePowerup('scrambleRival')}
            className="px-3 py-1.5 rounded-xl bg-rose-400 hover:bg-rose-300 text-white font-display font-bold text-xs border-b-2 border-rose-700 flex items-center gap-1 cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5" />
            Chalgʻitish ({profile.powerups.scrambleRival})
          </button>
        </div>
      )}

      {/* Real-time Dictionary Validation / Scramble Warning / Toast */}
      <div className="h-7 flex items-center justify-center px-4">
        {isKeyboardScrambled ? (
          <div className="px-3 py-1 rounded-xl bg-rose-600 text-white text-xs font-bold flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4" />
            Raqib klaviaturangizni chalgʻitdi!
          </div>
        ) : wordValidation === 'invalid_word' ? (
          <div className="px-3.5 py-1 rounded-xl bg-rose-600 text-white border border-rose-300 text-xs font-bold shadow-lg flex items-center gap-1.5 animate-wordy-pop">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            Lugʻatda bunday soʻz mavjud emas
          </div>
        ) : wordValidation === 'invalid_prefix' ? (
          <div className="px-3.5 py-1 rounded-xl bg-rose-600 text-white border border-rose-300 text-xs font-bold shadow-lg flex items-center gap-1.5 animate-wordy-pop">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            «{currentGuess}» bilan boshlanuvchi soʻz lugʻatda yoʻq
          </div>
        ) : toast ? (
          <div className="px-4 py-1 rounded-xl bg-slate-950/90 border border-amber-400/40 text-amber-200 text-xs font-bold shadow-lg">
            {toast}
          </div>
        ) : isValidFullWord ? (
          <div className="px-3 py-0.5 rounded-xl bg-emerald-600/90 text-white border border-emerald-300/60 text-[11px] font-bold shadow flex items-center gap-1 animate-wordy-pop">
            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
            Soʻz lugʻatda mavjud
          </div>
        ) : null}
      </div>

      {/* Tactile Wordle Grid */}
      <main className="flex-1 flex flex-col items-center justify-center px-3 py-1">
        <div
          className={`grid grid-rows-6 gap-1.5 w-full ${
            activeWordLen === 6 ? 'max-w-[335px] sm:max-w-[375px]' : 'max-w-[295px] sm:max-w-[320px]'
          }`}
        >
          {Array.from({ length: MAX_DUEL_GUESSES }).map((_, rIdx) => {
            const isSubmitted = rIdx < guesses.length;
            const isCurrent = rIdx === guesses.length;
            const word = isSubmitted ? guesses[rIdx] : isCurrent ? currentGuess : '';
            const evals = isSubmitted ? evaluateWordleGuess(word, currentTarget) : [];

            return (
              <div
                key={rIdx}
                className={`grid ${activeWordLen === 6 ? 'grid-cols-6' : 'grid-cols-5'} gap-1.5 ${
                  isCurrent && shakeRow ? 'animate-wordy-shake' : ''
                }`}
              >
                {Array.from({ length: activeWordLen }).map((__, cIdx) => {
                  const char = word[cIdx] || '';
                  const hintCh = isCurrent && !char ? revealedHintCols[cIdx] : '';
                  const st = isSubmitted ? evals[cIdx] : char ? 'tbd' : 'empty';
                  let tileCls =
                    isCurrent && isInvalidRealtime
                      ? 'bg-rose-500/20 dark:bg-rose-950/50 border-2 border-rose-400 text-white'
                      : 'bg-white/20 dark:bg-slate-800/75 border-2 border-white/40 dark:border-slate-600 text-white';
                  if (st === 'tbd') {
                    tileCls = isInvalidRealtime
                      ? 'bg-rose-100 text-rose-700 border-2 border-rose-500 border-b-4 border-b-rose-600 ring-2 ring-rose-400/60 animate-wordy-pop shadow-md'
                      : isValidFullWord
                      ? 'bg-emerald-50 dark:bg-slate-700 text-emerald-950 dark:text-white border-2 border-emerald-400 border-b-4 border-b-emerald-600 animate-wordy-pop shadow-md'
                      : 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white border-2 border-white dark:border-sky-400 border-b-4 border-b-slate-300 dark:border-b-slate-900 animate-wordy-pop shadow-md';
                  }
                  if (st === 'correct')
                    tileCls =
                      'bg-emerald-500 border-2 border-emerald-400 border-b-4 border-b-emerald-700 text-white animate-wordy-flip shadow-md';
                  if (st === 'present')
                    tileCls =
                      'bg-amber-300 border-2 border-amber-200 border-b-4 border-b-amber-600 text-amber-950 animate-wordy-flip shadow-md';
                  if (st === 'absent')
                    tileCls =
                      'bg-slate-700/90 border-2 border-slate-600 border-b-4 border-b-slate-900 text-white/85 animate-wordy-flip';

                  return (
                    <div
                      key={cIdx}
                      style={isSubmitted ? { animationDelay: `${cIdx * 50}ms` } : undefined}
                      className={`aspect-square rounded-2xl flex items-center justify-center font-display font-bold text-2xl ${tileCls}`}
                    >
                      {char || (hintCh ? <span className="text-amber-200/80 text-lg">{hintCh}</span> : null)}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </main>

      <footer className="w-full px-2 sm:px-4 pb-4 pt-1">
        <WordKeyboard
          keyStates={keyStates}
          onKey={handleKey}
          onEnter={handleEnter}
          onBackspace={handleBackspace}
          scrambled={isKeyboardScrambled}
          disabled={phase !== 'PLAYING' || paused}
          invalidWord={isInvalidRealtime}
        />
      </footer>

      {/* Pause Modal */}
      {paused && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80">
          <div className="w-full max-w-xs rounded-3xl bg-white dark:bg-slate-900 border-2 border-amber-300 dark:border-white/20 p-6 text-center text-slate-900 dark:text-white space-y-4">
            <h2 className="font-display font-bold text-2xl">Oʻyin toʻxtatildi</h2>
            <p className="text-xs text-slate-500 dark:text-slate-300">Taymer pauzada</p>
            <div className="flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => setPaused(false)}
                className="w-full py-3 rounded-2xl bg-emerald-500 text-white border-b-4 border-emerald-700 font-display font-bold text-sm cursor-pointer"
              >
                Davom etish
              </button>
              <button
                type="button"
                onClick={() => setPhase('VARIANT_PICK')}
                className="w-full py-3 rounded-2xl bg-slate-200 dark:bg-white/10 text-slate-800 dark:text-slate-200 font-bold text-sm cursor-pointer"
              >
                Dueldan chiqish
              </button>
            </div>
          </div>
        </div>
      )}

      <VictoryModal
        reward={victoryReward}
        onContinue={() => {
          setVictoryReward(null);
          setPhase('VARIANT_PICK');
        }}
        onPlayAgain={() => {
          setVictoryReward(null);
          if (connectionMode === 'online') {
            setOnlineRoom(null);
            setPhase('SETUP');
          } else if (connectionMode === 'offline_code') {
            const freshCode = encodeOfflineSyncCode(
              duelWordLen,
              customRounds,
              customDurationSec,
              generateSeed4()
            );
            startOfflineSyncedMatch(freshCode);
          } else {
            startAiMatch();
          }
        }}
      />
    </div>
  );
};
