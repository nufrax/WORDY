import React from 'react';
import { BarChart3, Flame, Swords, Trophy, X } from 'lucide-react';
import { calculateDayStreak } from '../services/playerService';
import { PlayerProfile } from '../types/game';
import { StatsDashboard } from './StatsDashboard';

interface StatsModalProps {
  open: boolean;
  profile: PlayerProfile;
  onClose: () => void;
  onOpenProfile: () => void;
}

export const StatsModal: React.FC<StatsModalProps> = ({
  open,
  profile,
  onClose,
  onOpenProfile,
}) => {
  if (!open) return null;

  const { stats } = profile;
  const { currentDayStreak, longestDayStreak } = calculateDayStreak(
    profile.dailyState?.activityDays
  );

  const classicRate =
    stats.classicPlayed > 0 ? Math.round((stats.classicWon / stats.classicPlayed) * 100) : 0;
  const duelRate =
    stats.duelsPlayed > 0 ? Math.round((stats.duelsWon / stats.duelsPlayed) * 100) : 0;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-xl max-h-[90vh] flex flex-col rounded-3xl bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-950 text-white border-2 border-indigo-400/50 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="shrink-0 px-5 py-4 bg-gradient-to-r from-indigo-600 via-blue-600 to-sky-600 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/15 border border-white/25 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h2 className="font-display font-bold text-lg sm:text-xl leading-none">
                OʻYINCHI STATISTIKASI
              </h2>
              <p className="text-xs text-sky-100 mt-1">
                {profile.displayName} · Daraja {profile.level}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="w-9 h-9 rounded-xl bg-black/25 hover:bg-black/35 flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 min-h-0 overflow-y-auto p-4 sm:p-5 space-y-4">
          <StatsDashboard
            profile={profile}
            onOpenProfile={() => {
              onClose();
              onOpenProfile();
            }}
          />

          {/* Detailed Mode Breakdown */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            <div className="rounded-2xl bg-white/8 border border-white/12 p-3">
              <div className="text-[11px] font-bold text-amber-200/80">Classic natija</div>
              <div className="font-mono-num font-bold text-lg text-white mt-0.5">
                {stats.classicWon}/{stats.classicPlayed}
              </div>
              <div className="text-[11px] text-emerald-300 font-semibold">
                {classicRate}% gʻalaba
              </div>
            </div>

            <div className="rounded-2xl bg-white/8 border border-white/12 p-3">
              <div className="text-[11px] font-bold text-sky-200/80 flex items-center gap-1">
                <Swords className="w-3.5 h-3.5" />
                Duel natija
              </div>
              <div className="font-mono-num font-bold text-lg text-white mt-0.5">
                {stats.duelsWon}/{stats.duelsPlayed}
              </div>
              <div className="text-[11px] text-emerald-300 font-semibold">
                {duelRate}% gʻalaba
              </div>
            </div>

            <div className="rounded-2xl bg-white/8 border border-white/12 p-3">
              <div className="text-[11px] font-bold text-orange-200/80 flex items-center gap-1">
                <Flame className="w-3.5 h-3.5" />
                Kunlik seriya
              </div>
              <div className="font-mono-num font-bold text-lg text-orange-300 mt-0.5">
                {currentDayStreak} kun
              </div>
              <div className="text-[11px] text-white/65 font-semibold">
                Rekord: {longestDayStreak} kun
              </div>
            </div>

            <div className="rounded-2xl bg-white/8 border border-white/12 p-3">
              <div className="text-[11px] font-bold text-rose-200/80">Daily yakunlar</div>
              <div className="font-mono-num font-bold text-lg text-white mt-0.5">
                {stats.dailyCompleted} kun
              </div>
              <div className="text-[11px] text-white/65 font-semibold">5 talik sandiq</div>
            </div>

            <div className="rounded-2xl bg-white/8 border border-white/12 p-3">
              <div className="text-[11px] font-bold text-violet-200/80">Mixed & Circle</div>
              <div className="font-mono-num font-bold text-lg text-white mt-0.5">
                {stats.mixedSolved} / {stats.circleWordsFound}
              </div>
              <div className="text-[11px] text-white/65 font-semibold">
                Circle daraja {stats.circleLevel}
              </div>
            </div>

            <div className="rounded-2xl bg-white/8 border border-white/12 p-3">
              <div className="text-[11px] font-bold text-emerald-200/80 flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5" />
                Sarflangan UZC
              </div>
              <div className="font-mono-num font-bold text-lg text-amber-300 mt-0.5">
                {stats.totalUzcSpent}
              </div>
              <div className="text-[11px] text-white/65 font-semibold">
                Balans: {profile.uzc} UZC
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
