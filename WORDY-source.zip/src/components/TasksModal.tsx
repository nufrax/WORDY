import React, { useState } from 'react';
import { X, ClipboardCheck, Star, Trophy, Target, Zap, Check } from 'lucide-react';
import { getActiveTaskDefinitions } from '../services/playerService';
import { PlayerProfile, TaskDefinition } from '../types/game';
import { UzcCoinIcon } from './GameIcons';

interface TasksModalProps {
  open: boolean;
  profile: PlayerProfile;
  onClose: () => void;
  onClaimTask: (task: TaskDefinition) => void;
}

export const TasksModal: React.FC<TasksModalProps> = ({
  open,
  profile,
  onClose,
  onClaimTask,
}) => {
  const [tab, setTab] = useState<'daily' | 'weekly' | 'achievement'>('daily');
  if (!open) return null;

  const list = getActiveTaskDefinitions().filter((t) => t.category === tab);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75"
      role="dialog"
      aria-modal="true"
    >
      <div className="w-full max-w-lg max-h-[86vh] flex flex-col rounded-3xl bg-gradient-to-b from-amber-50 to-orange-100 dark:from-slate-900 dark:to-slate-950 text-slate-900 dark:text-slate-100 border-2 border-orange-400/60 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-rose-500 to-orange-500 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ClipboardCheck className="w-7 h-7 text-amber-200" />
            <h2 className="font-display font-bold text-xl tracking-wide">TOPSHIRIQLAR</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Yopish"
            className="w-9 h-9 rounded-xl bg-black/20 hover:bg-black/30 flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Segmented Tabs */}
        <div className="px-4 pt-3 pb-2 grid grid-cols-3 gap-2">
          {(
            [
              { id: 'daily', label: 'Kunlik' },
              { id: 'weekly', label: 'Haftalik' },
              { id: 'achievement', label: 'Yutuqlar' },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`py-2 rounded-xl text-xs font-bold cursor-pointer transition-colors ${
                tab === t.id
                  ? 'bg-amber-400 text-amber-950 border-b-2 border-amber-600'
                  : 'bg-white/75 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Task List */}
        <div className="flex-1 overflow-y-auto px-4 pb-5 space-y-2.5">
          {list.map((task) => {
            const state = profile.tasks[task.id] || { progress: 0, claimed: false };
            const progress = Math.min(task.target, state.progress);
            const ready = progress >= task.target && !state.claimed;
            const pct = Math.round((progress / task.target) * 100);

            return (
              <div
                key={task.id}
                className="rounded-2xl bg-white dark:bg-slate-800 border border-orange-200 dark:border-slate-700 p-3.5 flex items-center justify-between gap-3 shadow-sm"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="w-10 h-10 rounded-xl bg-orange-100 dark:bg-slate-700 flex items-center justify-center shrink-0">
                    {task.category === 'daily' ? (
                      <Star className="w-5 h-5 text-amber-500" />
                    ) : task.category === 'weekly' ? (
                      <Zap className="w-5 h-5 text-sky-500" />
                    ) : (
                      <Trophy className="w-5 h-5 text-rose-500" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="font-bold text-sm truncate">{task.titleUz}</div>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex-1 h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                        <div
                          style={{ width: `${pct}%` }}
                          className="h-full bg-emerald-500 transition-all"
                        />
                      </div>
                      <span className="font-mono-num text-xs font-bold text-slate-500 dark:text-slate-400">
                        {progress}/{task.target}
                      </span>
                    </div>
                  </div>
                </div>

                {state.claimed ? (
                  <div className="px-3 py-1.5 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-1 shrink-0">
                    <Check className="w-3.5 h-3.5" />
                    Olindi
                  </div>
                ) : ready ? (
                  <button
                    type="button"
                    onClick={() => onClaimTask(task)}
                    className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs border-b-2 border-emerald-700 flex items-center gap-1 cursor-pointer shrink-0 animate-wordy-pop"
                  >
                    <UzcCoinIcon className="w-4 h-4" />
                    +{task.rewardUzc}
                  </button>
                ) : (
                  <div className="flex items-center gap-1 text-xs font-bold text-amber-600 dark:text-amber-300 shrink-0">
                    <UzcCoinIcon className="w-4 h-4" />
                    <span className="font-mono-num">{task.rewardUzc}</span>
                  </div>
                )}
              </div>
            );
          })}

          <div className="pt-2 text-center text-xs text-slate-500 dark:text-slate-400 flex items-center justify-center gap-1.5">
            <Target className="w-3.5 h-3.5" />
            Oʻyinlarni yakunlab UZC mukofotlarini qoʻlga kiriting
          </div>
        </div>
      </div>
    </div>
  );
};
