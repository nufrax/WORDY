import React from 'react';
import { Delete, CornerDownLeft } from 'lucide-react';
import { LetterState } from '../types/game';

const ROWS = [
  ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
  ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
  ['ENTER', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', 'BACK'],
];

interface WordKeyboardProps {
  keyStates: Record<string, LetterState>;
  onKey: (letter: string) => void;
  onEnter: () => void;
  onBackspace: () => void;
  scrambled?: boolean;
  disabled?: boolean;
  invalidWord?: boolean;
}

export const WordKeyboard: React.FC<WordKeyboardProps> = ({
  keyStates,
  onKey,
  onEnter,
  onBackspace,
  scrambled = false,
  disabled = false,
  invalidWord = false,
}) => {
  const getStyle = (key: string) => {
    const state = keyStates[key];
    if (state === 'correct') {
      return 'bg-emerald-500 text-white border-b-4 border-emerald-700 shadow-sm hover:bg-emerald-400';
    }
    if (state === 'present') {
      return 'bg-amber-400 text-amber-950 border-b-4 border-amber-600 shadow-sm hover:bg-amber-300';
    }
    if (state === 'absent') {
      return 'bg-slate-600/85 dark:bg-slate-800 text-slate-200/80 border-b-4 border-slate-800 dark:border-slate-950';
    }
    return 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-50 border-b-4 border-slate-300 dark:border-slate-900 hover:bg-amber-50 dark:hover:bg-slate-600 shadow-sm';
  };

  return (
    <div className="w-full max-w-xl mx-auto flex flex-col gap-1.5 sm:gap-2 select-none">
      {ROWS.map((row, rIdx) => (
        <div key={rIdx} className="flex justify-center gap-1 sm:gap-1.5">
          {row.map((key, kIdx) => {
            if (key === 'ENTER') {
              return (
                <button
                  key={key}
                  type="button"
                  disabled={disabled}
                  onClick={onEnter}
                  aria-label="Yuborish"
                  className={`px-2.5 sm:px-4 h-11 sm:h-12 rounded-xl font-display font-bold text-xs sm:text-sm border-b-4 flex items-center justify-center gap-1 transition-all cursor-pointer disabled:opacity-50 whitespace-nowrap shrink-0 active:translate-y-0.5 ${
                    invalidWord
                      ? 'bg-rose-500/80 border-rose-700 text-white opacity-75'
                      : 'bg-emerald-500 hover:bg-emerald-400 border-emerald-700 text-white shadow-sm'
                  }`}
                >
                  <CornerDownLeft className="w-4 h-4" />
                  <span className="hidden sm:inline">OK</span>
                </button>
              );
            }
            if (key === 'BACK') {
              return (
                <button
                  key={key}
                  type="button"
                  disabled={disabled}
                  onClick={onBackspace}
                  aria-label="Oʻchirish"
                  className="px-3 sm:px-4 h-11 sm:h-12 rounded-xl bg-rose-500 hover:bg-rose-400 active:translate-y-0.5 text-white font-bold border-b-4 border-rose-700 flex items-center justify-center transition-transform cursor-pointer disabled:opacity-50 shrink-0 shadow-sm"
                >
                  <Delete className="w-5 h-5" />
                </button>
              );
            }

            const displayChar = scrambled ? ROWS[rIdx][(kIdx + 3) % row.length] : key;
            const actualChar = scrambled && displayChar !== 'ENTER' && displayChar !== 'BACK' ? displayChar : key;

            return (
              <button
                key={key}
                type="button"
                disabled={disabled}
                onClick={() => onKey(actualChar)}
                className={`flex-1 max-w-[44px] h-11 sm:h-12 rounded-xl font-display font-bold text-base sm:text-lg active:translate-y-0.5 transition-transform flex items-center justify-center cursor-pointer disabled:opacity-50 ${getStyle(actualChar)}`}
              >
                {actualChar}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
};
