import { doc, getDoc, serverTimestamp, setDoc, updateDoc } from 'firebase/firestore';
import { getCurrentWeekKey, getTodayDateKey, seededRandom } from '../data/words';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import {
  AchievementBadgeDefinition,
  AvatarId,
  PlayerProfile,
  TaskDefinition,
  ThemeId,
} from '../types/game';

const STORAGE_KEY = 'wordy_uz_profile_v2';

export const DAILY_TASK_POOL: TaskDefinition[] = [
  {
    id: 'd_classic_3',
    category: 'daily',
    titleUz: '3 ta Classic oʻyin oʻynang',
    target: 3,
    rewardUzc: 50,
    rewardXp: 40,
    statKey: 'classicPlayed',
  },
  {
    id: 'd_classic_win_2',
    category: 'daily',
    titleUz: 'Classic rejimida 2 marta yuting',
    target: 2,
    rewardUzc: 85,
    rewardXp: 65,
    statKey: 'classicWon',
  },
  {
    id: 'd_daily_win',
    category: 'daily',
    titleUz: 'Kunlik 5 ta soʻzni yeching',
    target: 1,
    rewardUzc: 100,
    rewardXp: 70,
    statKey: 'dailyCompleted',
  },
  {
    id: 'd_circle_10',
    category: 'daily',
    titleUz: 'Circle rejimida 10 ta soʻz toping',
    target: 10,
    rewardUzc: 75,
    rewardXp: 55,
    statKey: 'circleWordsFound',
  },
  {
    id: 'd_circle_6',
    category: 'daily',
    titleUz: 'Circle rejimida 6 ta soʻz toping',
    target: 6,
    rewardUzc: 55,
    rewardXp: 45,
    statKey: 'circleWordsFound',
  },
  {
    id: 'd_mixed_4',
    category: 'daily',
    titleUz: 'Mixed rejimida 4 ta soʻzni yeching',
    target: 4,
    rewardUzc: 65,
    rewardXp: 50,
    statKey: 'mixedSolved',
  },
  {
    id: 'd_mixed_7',
    category: 'daily',
    titleUz: 'Mixed rejimida 7 ta soʻz toping',
    target: 7,
    rewardUzc: 90,
    rewardXp: 65,
    statKey: 'mixedSolved',
  },
  {
    id: 'd_together_1',
    category: 'daily',
    titleUz: 'Together duelida bellashing',
    target: 1,
    rewardUzc: 80,
    rewardXp: 60,
    statKey: 'duelsPlayed',
  },
  {
    id: 'd_duel_win_1',
    category: 'daily',
    titleUz: 'Bugun 1 ta duelda gʻolib boʻling',
    target: 1,
    rewardUzc: 110,
    rewardXp: 80,
    statKey: 'duelsWon',
  },
  {
    id: 'd_classic_5',
    category: 'daily',
    titleUz: '5 ta Classic oʻyin yakunlang',
    target: 5,
    rewardUzc: 95,
    rewardXp: 70,
    statKey: 'classicPlayed',
  },
];

export const WEEKLY_TASK_POOL: TaskDefinition[] = [
  {
    id: 'w_classic_win_5',
    category: 'weekly',
    titleUz: 'Classic rejimida 5 marta yuting',
    target: 5,
    rewardUzc: 200,
    rewardXp: 150,
    statKey: 'classicWon',
  },
  {
    id: 'w_classic_play_12',
    category: 'weekly',
    titleUz: 'Hafta davomida 12 ta Classic oʻynang',
    target: 12,
    rewardUzc: 180,
    rewardXp: 130,
    statKey: 'classicPlayed',
  },
  {
    id: 'w_mixed_10',
    category: 'weekly',
    titleUz: 'Mixed rejimida 10 ta soʻz toping',
    target: 10,
    rewardUzc: 150,
    rewardXp: 110,
    statKey: 'mixedSolved',
  },
  {
    id: 'w_duel_win_3',
    category: 'weekly',
    titleUz: 'Duellarda 3 marta gʻolib boʻling',
    target: 3,
    rewardUzc: 250,
    rewardXp: 180,
    statKey: 'duelsWon',
  },
  {
    id: 'w_circle_25',
    category: 'weekly',
    titleUz: 'Circle rejimida 25 ta soʻz toping',
    target: 25,
    rewardUzc: 210,
    rewardXp: 155,
    statKey: 'circleWordsFound',
  },
  {
    id: 'w_daily_3',
    category: 'weekly',
    titleUz: '3 kun Kunlik topishmoqni yakunlang',
    target: 3,
    rewardUzc: 260,
    rewardXp: 190,
    statKey: 'dailyCompleted',
  },
  {
    id: 'w_duel_play_6',
    category: 'weekly',
    titleUz: '6 ta Together duelida qatnashing',
    target: 6,
    rewardUzc: 190,
    rewardXp: 140,
    statKey: 'duelsPlayed',
  },
];

export const PERMANENT_TASKS: TaskDefinition[] = [
  {
    id: 'a_first_classic',
    category: 'achievement',
    titleUz: 'Ilk Classic Wordle gʻalabasi',
    target: 1,
    rewardUzc: 100,
    rewardXp: 80,
    statKey: 'classicWon',
  },
  {
    id: 'a_circle_50',
    category: 'achievement',
    titleUz: 'Circle ustasi: 50 ta soʻz toping',
    target: 50,
    rewardUzc: 350,
    rewardXp: 260,
    statKey: 'circleWordsFound',
  },
  {
    id: 'a_duel_10',
    category: 'achievement',
    titleUz: 'Duel chempioni: 10 ta gʻalaba',
    target: 10,
    rewardUzc: 500,
    rewardXp: 400,
    statKey: 'duelsWon',
  },
];

function pickDeterministic<T>(pool: T[], count: number, seed: string): T[] {
  const rng = seededRandom(seed);
  const copy = [...pool];
  const picked: T[] = [];
  for (let i = 0; i < count && copy.length > 0; i++) {
    const idx = Math.floor(rng() * copy.length);
    picked.push(copy.splice(idx, 1)[0]);
  }
  return picked;
}

export function getActiveTaskDefinitions(
  dateKey = getTodayDateKey(),
  weekKey = getCurrentWeekKey()
): TaskDefinition[] {
  const daily = pickDeterministic(DAILY_TASK_POOL, 4, `WORDY_DAILY_TASKS_${dateKey}`);
  const weekly = pickDeterministic(WEEKLY_TASK_POOL, 3, `WORDY_WEEKLY_TASKS_${weekKey}`);
  return [...daily, ...weekly, ...PERMANENT_TASKS];
}

export const TASK_DEFINITIONS: TaskDefinition[] = getActiveTaskDefinitions();

export interface ShopItem {
  id: string;
  category: 'hints' | 'powerups' | 'themes' | 'avatars';
  titleUz: string;
  descUz: string;
  priceUzc: number;
  amount?: number;
  themeId?: ThemeId;
  avatarId?: AvatarId;
  powerupKey?: 'revealLetter' | 'freezeTime' | 'scrambleRival' | 'skipWord';
}

export const SHOP_ITEMS: ShopItem[] = [
  {
    id: 'hint_3',
    category: 'hints',
    titleUz: '3× Maslahat',
    descUz: 'Istalgan soʻzdan bitta harf ochadi',
    priceUzc: 60,
    amount: 3,
  },
  {
    id: 'hint_10',
    category: 'hints',
    titleUz: '10× Maslahat',
    descUz: 'Katta maslahatlar toʻplami',
    priceUzc: 175,
    amount: 10,
  },
  {
    id: 'booster_skip_2',
    category: 'hints',
    titleUz: '2× Oʻtkazish',
    descUz: 'Qiyin soʻzni keyingisiga almashtiradi',
    priceUzc: 90,
    amount: 2,
    powerupKey: 'skipWord',
  },
  {
    id: 'booster_skip_5',
    category: 'hints',
    titleUz: '5× Oʻtkazish',
    descUz: '5 ta tezkor soʻz almashtirgich',
    priceUzc: 200,
    amount: 5,
    powerupKey: 'skipWord',
  },
  {
    id: 'pwr_reveal',
    category: 'powerups',
    titleUz: 'Harf ochish ×2',
    descUz: 'Battle Duelda joriy soʻzdan bitta harf ochadi',
    priceUzc: 80,
    amount: 2,
    powerupKey: 'revealLetter',
  },
  {
    id: 'pwr_freeze',
    category: 'powerups',
    titleUz: 'Vaqt qoʻshish (+15s) ×2',
    descUz: 'Battle Duel taymeriga 15 soniya qoʻshadi',
    priceUzc: 90,
    amount: 2,
    powerupKey: 'freezeTime',
  },
  {
    id: 'pwr_scramble',
    category: 'powerups',
    titleUz: 'Raqibni chalgʻitish ×2',
    descUz: 'Battle Duelda raqib klaviaturasini 6 soniyaga chalkashtiradi',
    priceUzc: 110,
    amount: 2,
    powerupKey: 'scrambleRival',
  },
  {
    id: 'theme_blue',
    category: 'themes',
    titleUz: 'Moviy Okean mavzusi',
    descUz: 'Bosh ekran va oʻyin maydoni uchun chuqur moviy bezak',
    priceUzc: 180,
    themeId: 'blue',
  },
  {
    id: 'theme_emerald',
    category: 'themes',
    titleUz: 'Zumrad Oʻrmon mavzusi',
    descUz: 'Yorqin yashil va oltin uygʻunlikdagi arena bezagi',
    priceUzc: 240,
    themeId: 'emerald',
  },
  {
    id: 'avatar_girl',
    category: 'avatars',
    titleUz: 'Zukko Malika avatari',
    descUz: 'Profilingiz va duellar uchun maxsus avatar',
    priceUzc: 100,
    avatarId: 'girl_amber',
  },
  {
    id: 'avatar_owl',
    category: 'avatars',
    titleUz: 'Bilimdon Boyqush',
    descUz: 'Soʻz ustalarining ramziy avatari',
    priceUzc: 250,
    avatarId: 'scholar_owl',
  },
  {
    id: 'avatar_shades',
    category: 'avatars',
    titleUz: 'Koʻzoynakli Usta',
    descUz: 'Battle Duel chempionlari uslubidagi avatar',
    priceUzc: 400,
    avatarId: 'cool_shades',
  },
  {
    id: 'avatar_crown',
    category: 'avatars',
    titleUz: 'Oltin Toj sohibi',
    descUz: 'Eng nufuzli qirollik avatari',
    priceUzc: 750,
    avatarId: 'crown_pro',
  },
  {
    id: 'avatar_cyber',
    category: 'avatars',
    titleUz: 'Kiber Usta avatari',
    descUz: 'Eng yuqori darajali futuristik afsonaviy avatar',
    priceUzc: 1200,
    avatarId: 'bot_cyber',
  },
];

export const ACHIEVEMENT_BADGES: AchievementBadgeDefinition[] = [
  {
    id: 'badge_first_win',
    iconKey: 'first_win',
    titleUz: 'Ilk Gʻalaba',
    descUz: 'Istalgan rejimda birinchi gʻalabani qoʻlga kiriting',
    target: 1,
    rewardUzc: 50,
    rewardXp: 40,
    metric: (p) => p.stats.classicWon + p.stats.duelsWon + p.stats.dailyCompleted,
  },
  {
    id: 'badge_streak_5',
    iconKey: 'streak_5',
    titleUz: 'Olovli Seriya (5×)',
    descUz: 'Ketma-ket 5 ta gʻalaba qozoning',
    target: 5,
    rewardUzc: 150,
    rewardXp: 100,
    metric: (p) => p.stats.bestWinStreak,
  },
  {
    id: 'badge_streak_10',
    iconKey: 'streak_10',
    titleUz: '10 ta Ketma-ket Gʻalaba',
    descUz: 'Magʻlubiyatsiz 10 ta oʻyinda ketma-ket gʻolib boʻling',
    target: 10,
    rewardUzc: 500,
    rewardXp: 300,
    metric: (p) => p.stats.bestWinStreak,
  },
  {
    id: 'badge_spent_1000',
    iconKey: 'spender_1000',
    titleUz: '1000 UZC Sarflandi',
    descUz: 'Doʻkon va yordamchilarga jami 1000 UZC sarflang',
    target: 1000,
    rewardUzc: 250,
    rewardXp: 150,
    metric: (p) => p.stats.totalUzcSpent,
  },
  {
    id: 'badge_earned_2000',
    iconKey: 'treasury_2000',
    titleUz: '2000 UZC Xazinasi',
    descUz: 'Oʻyin davomida jami 2000 UZC ishlab toping',
    target: 2000,
    rewardUzc: 300,
    rewardXp: 200,
    metric: (p) => p.stats.totalUzcEarned,
  },
  {
    id: 'badge_circle_50',
    iconKey: 'circle_master',
    titleUz: 'Soʻz Zargari',
    descUz: 'Circle rejimida 50 ta maqsadli soʻz toping',
    target: 50,
    rewardUzc: 200,
    rewardXp: 150,
    metric: (p) => p.stats.circleWordsFound,
  },
  {
    id: 'badge_duel_10',
    iconKey: 'duel_champ',
    titleUz: 'Duel Chempioni',
    descUz: 'Together duellarida 10 marta gʻalaba qozoning',
    target: 10,
    rewardUzc: 400,
    rewardXp: 250,
    metric: (p) => p.stats.duelsWon,
  },
  {
    id: 'badge_collector',
    iconKey: 'collector',
    titleUz: 'Uslub Kolleksioneri',
    descUz: 'Kamida 5 ta avatar yoki mavzuga ega boʻling',
    target: 5,
    rewardUzc: 200,
    rewardXp: 140,
    metric: (p) => p.ownedAvatars.length + p.ownedThemes.length,
  },
];

export function xpNeededForLevel(level: number): number {
  return 100 + (level - 1) * 50;
}

export function applyXpGain(currentLevel: number, currentXp: number, gainedXp: number) {
  let lvl = currentLevel;
  let xp = currentXp + gainedXp;
  while (xp >= xpNeededForLevel(lvl)) {
    xp -= xpNeededForLevel(lvl);
    lvl += 1;
  }
  return { level: lvl, xp };
}

export function createDefaultProfile(uid = 'local_player'): PlayerProfile {
  const today = getTodayDateKey();
  const weekKey = getCurrentWeekKey();
  const activeTasks = getActiveTaskDefinitions(today, weekKey);
  const initialTasks: Record<string, { progress: number; claimed: boolean }> = {};
  activeTasks.forEach((t) => {
    initialTasks[t.id] = { progress: 0, claimed: false };
  });
  ACHIEVEMENT_BADGES.forEach((b) => {
    initialTasks[b.id] = { progress: 0, claimed: false };
  });

  return {
    uid,
    displayName: 'Oʻyinchi 1',
    avatarId: 'boy_blue',
    uzc: 0,
    xp: 0,
    level: 1,
    hints: 0,
    powerups: {
      revealLetter: 0,
      freezeTime: 0,
      scrambleRival: 0,
      skipWord: 0,
    },
    ownedThemes: ['sunset', 'blue'],
    activeTheme: 'sunset',
    ownedAvatars: ['boy_blue'],
    dailyState: {
      dateKey: today,
      weekKey,
      solvedIndices: [],
      claimedChest: false,
      activityDays: [],
    },
    lastFreeCoinDate: '',
    tasks: initialTasks,
    stats: {
      classicPlayed: 0,
      classicWon: 0,
      classicStreak: 0,
      dailyCompleted: 0,
      circleWordsFound: 0,
      circleLevel: 1,
      mixedSolved: 0,
      duelsPlayed: 0,
      duelsWon: 0,
      currentWinStreak: 0,
      bestWinStreak: 0,
      totalUzcEarned: 0,
      totalUzcSpent: 0,
    },
    settings: {
      sound: true,
      vibration: true,
      darkMode: false,
      blueTheme: false,
      hardMode: false,
    },
  };
}

function sanitizeActivityDays(days?: string[]): string[] {
  if (!Array.isArray(days)) return [];
  const unique = Array.from(
    new Set(days.filter((d) => typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d)))
  ).sort();
  return unique.slice(-90);
}

export function normalizeProfileForToday(profile: PlayerProfile): PlayerProfile {
  const today = getTodayDateKey();
  const weekKey = getCurrentWeekKey();
  const updated = { ...profile };

  const preservedActivityDays = sanitizeActivityDays(updated.dailyState?.activityDays);
  const isNewDay = !updated.dailyState || updated.dailyState.dateKey !== today;
  const isNewWeek = !updated.dailyState?.weekKey || updated.dailyState.weekKey !== weekKey;

  if (isNewDay) {
    updated.dailyState = {
      dateKey: today,
      weekKey,
      solvedIndices: [],
      claimedChest: false,
      activityDays: preservedActivityDays,
    };
  } else {
    updated.dailyState = {
      ...updated.dailyState,
      weekKey: isNewWeek ? weekKey : updated.dailyState.weekKey,
      activityDays: preservedActivityDays,
    };
  }

  const activeTasks = getActiveTaskDefinitions(today, weekKey);
  const activeIds = new Set(activeTasks.map((t) => t.id));
  const badgeIds = new Set(ACHIEVEMENT_BADGES.map((b) => b.id));

  const nextTasks: Record<string, { progress: number; claimed: boolean }> = {};
  for (const [id, val] of Object.entries(updated.tasks || {})) {
    // Drop expired daily/weekly task entries when day/week rotates; keep active + achievements
    if (isNewDay && id.startsWith('d_')) continue;
    if (isNewWeek && id.startsWith('w_')) continue;
    if (activeIds.has(id) || badgeIds.has(id)) {
      nextTasks[id] = val;
    }
  }

  for (const def of activeTasks) {
    if (!nextTasks[def.id]) {
      nextTasks[def.id] = { progress: 0, claimed: false };
    }
  }
  for (const badge of ACHIEVEMENT_BADGES) {
    if (!nextTasks[badge.id]) {
      nextTasks[badge.id] = { progress: 0, claimed: false };
    }
  }
  updated.tasks = nextTasks;

  updated.stats = {
    classicPlayed: updated.stats?.classicPlayed || 0,
    classicWon: updated.stats?.classicWon || 0,
    classicStreak: updated.stats?.classicStreak || 0,
    dailyCompleted: updated.stats?.dailyCompleted || 0,
    circleWordsFound: updated.stats?.circleWordsFound || 0,
    circleLevel: updated.stats?.circleLevel || 1,
    mixedSolved: updated.stats?.mixedSolved || 0,
    duelsPlayed: updated.stats?.duelsPlayed || 0,
    duelsWon: updated.stats?.duelsWon || 0,
    currentWinStreak: updated.stats?.currentWinStreak || 0,
    bestWinStreak: updated.stats?.bestWinStreak || 0,
    totalUzcEarned: updated.stats?.totalUzcEarned || 0,
    totalUzcSpent: updated.stats?.totalUzcSpent || 0,
  };

  updated.powerups = {
    revealLetter: updated.powerups?.revealLetter || 0,
    freezeTime: updated.powerups?.freezeTime || 0,
    scrambleRival: updated.powerups?.scrambleRival || 0,
    skipWord: updated.powerups?.skipWord || 0,
  };

  if (!updated.ownedThemes || updated.ownedThemes.length === 0) {
    updated.ownedThemes = ['sunset', 'blue'];
  }
  if (!updated.ownedAvatars || updated.ownedAvatars.length === 0) {
    updated.ownedAvatars = ['boy_blue'];
  }

  return updated;
}

export function evaluateAchievements(profile: PlayerProfile): {
  profile: PlayerProfile;
  newlyUnlocked: AchievementBadgeDefinition[];
} {
  let current = normalizeProfileForToday(profile);
  const newlyUnlocked: AchievementBadgeDefinition[] = [];

  for (let pass = 0; pass < ACHIEVEMENT_BADGES.length; pass++) {
    let unlockedInPass = false;
    const nextTasks = { ...current.tasks };
    let bonusUzc = 0;
    let bonusXp = 0;

    for (const badge of ACHIEVEMENT_BADGES) {
      const value = Math.min(badge.target, Math.max(0, badge.metric(current)));
      const existing = nextTasks[badge.id] || { progress: 0, claimed: false };

      if (!existing.claimed && value >= badge.target) {
        nextTasks[badge.id] = { progress: badge.target, claimed: true };
        bonusUzc += badge.rewardUzc;
        bonusXp += badge.rewardXp;
        newlyUnlocked.push(badge);
        unlockedInPass = true;
      } else if (existing.progress !== value) {
        nextTasks[badge.id] = { ...existing, progress: value };
      }
    }

    const { level, xp } = applyXpGain(current.level, current.xp, bonusXp);
    current = {
      ...current,
      uzc: current.uzc + bonusUzc,
      level,
      xp,
      tasks: nextTasks,
      stats: {
        ...current.stats,
        totalUzcEarned: (current.stats.totalUzcEarned || 0) + bonusUzc,
      },
    };

    if (!unlockedInPass) break;
  }

  return { profile: current, newlyUnlocked };
}

export function recordTodayActivity(profile: PlayerProfile): PlayerProfile {
  const today = getTodayDateKey();
  const existing = sanitizeActivityDays(profile.dailyState?.activityDays);
  if (existing.includes(today)) return profile;
  return {
    ...profile,
    dailyState: {
      ...profile.dailyState,
      activityDays: sanitizeActivityDays([...existing, today]),
    },
  };
}

function addDaysToDateKey(dateKey: string, deltaDays: number): string {
  const [y, m, d] = dateKey.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + deltaDays));
  const yy = dt.getUTCFullYear();
  const mm = String(dt.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(dt.getUTCDate()).padStart(2, '0');
  return `${yy}-${mm}-${dd}`;
}

export function calculateDayStreak(activityDays?: string[]): {
  currentDayStreak: number;
  longestDayStreak: number;
  activeSet: Set<string>;
} {
  const clean = sanitizeActivityDays(activityDays);
  const activeSet = new Set(clean);
  if (clean.length === 0) {
    return { currentDayStreak: 0, longestDayStreak: 0, activeSet };
  }

  let longest = 0;
  let run = 0;
  for (let i = 0; i < clean.length; i++) {
    if (i === 0 || addDaysToDateKey(clean[i - 1], 1) === clean[i]) {
      run += 1;
    } else {
      run = 1;
    }
    if (run > longest) longest = run;
  }

  const today = getTodayDateKey();
  const yesterday = addDaysToDateKey(today, -1);
  let current = 0;
  let cursor = activeSet.has(today) ? today : activeSet.has(yesterday) ? yesterday : '';
  while (cursor && activeSet.has(cursor)) {
    current += 1;
    cursor = addDaysToDateKey(cursor, -1);
  }

  return { currentDayStreak: current, longestDayStreak: longest, activeSet };
}

export function loadLocalProfile(): PlayerProfile {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createDefaultProfile();
    const parsed = JSON.parse(raw) as Partial<PlayerProfile>;
    const base = createDefaultProfile(parsed.uid || 'local_player');
    return normalizeProfileForToday({
      ...base,
      ...parsed,
      powerups: { ...base.powerups, ...(parsed.powerups || {}) },
      stats: { ...base.stats, ...(parsed.stats || {}) },
      settings: { ...base.settings, ...(parsed.settings || {}) },
      tasks: { ...base.tasks, ...(parsed.tasks || {}) },
    });
  } catch {
    return createDefaultProfile();
  }
}

export function saveLocalProfile(profile: PlayerProfile): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  } catch {
    // Ignore storage quota issues
  }
}

export function incrementTaskStat(
  profile: PlayerProfile,
  statDelta: Partial<Record<TaskDefinition['statKey'], number>>
): PlayerProfile {
  const activeTasks = getActiveTaskDefinitions();
  const nextStats = { ...profile.stats };
  const nextTasks = { ...profile.tasks };

  for (const [key, delta] of Object.entries(statDelta)) {
    const k = key as TaskDefinition['statKey'];
    const amount = delta || 0;
    nextStats[k] = (nextStats[k] || 0) + amount;

    for (const def of activeTasks) {
      if (def.statKey === k) {
        const cur = nextTasks[def.id] || { progress: 0, claimed: false };
        nextTasks[def.id] = {
          ...cur,
          progress: Math.min(def.target, cur.progress + amount),
        };
      }
    }
  }

  return {
    ...profile,
    stats: nextStats,
    tasks: nextTasks,
  };
}

function serializeForFirestore(profile: PlayerProfile, uid: string) {
  return {
    uid,
    displayName: (profile.displayName || 'Oʻyinchi 1').slice(0, 32),
    avatarId: profile.avatarId || 'boy_blue',
    uzc: Math.max(0, Math.floor(profile.uzc)),
    xp: Math.max(0, Math.floor(profile.xp)),
    level: Math.max(1, Math.floor(profile.level)),
    hints: Math.max(0, Math.floor(profile.hints)),
    powerups: profile.powerups,
    ownedThemes: profile.ownedThemes.length > 0 ? profile.ownedThemes : ['sunset', 'blue'],
    ownedAvatars: profile.ownedAvatars.length > 0 ? profile.ownedAvatars : ['boy_blue'],
    dailyState: profile.dailyState,
    tasks: profile.tasks,
    stats: profile.stats,
    settings: {
      ...profile.settings,
      activeTheme: profile.activeTheme,
      lastFreeCoinDate: profile.lastFreeCoinDate,
    },
  };
}

export async function syncProfileToCloud(profile: PlayerProfile): Promise<PlayerProfile> {
  const user = auth.currentUser;
  if (!user) return profile;

  const userRef = doc(db, 'users', user.uid);
  const path = `users/${user.uid}`;

  let existingSnap;
  try {
    existingSnap = await getDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }

  const payload = serializeForFirestore(profile, user.uid);

  if (!existingSnap.exists()) {
    try {
      await setDoc(userRef, {
        ...payload,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      return { ...profile, uid: user.uid };
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  } else {
    try {
      await updateDoc(userRef, {
        displayName: payload.displayName,
        avatarId: payload.avatarId,
        uzc: payload.uzc,
        xp: payload.xp,
        level: payload.level,
        hints: payload.hints,
        powerups: payload.powerups,
        ownedThemes: payload.ownedThemes,
        ownedAvatars: payload.ownedAvatars,
        dailyState: payload.dailyState,
        tasks: payload.tasks,
        stats: payload.stats,
        settings: payload.settings,
        updatedAt: serverTimestamp(),
      });
      return { ...profile, uid: user.uid };
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  }
}

export async function loadAndMergeCloudProfile(localProfile: PlayerProfile): Promise<PlayerProfile> {
  const user = auth.currentUser;
  if (!user) return localProfile;

  const userRef = doc(db, 'users', user.uid);
  const path = `users/${user.uid}`;

  let snap;
  try {
    snap = await getDoc(userRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }

  if (!snap.exists()) {
    const seeded = {
      ...localProfile,
      uid: user.uid,
      displayName:
        localProfile.displayName === 'Oʻyinchi 1' && user.displayName
          ? user.displayName.slice(0, 24)
          : localProfile.displayName,
    };
    return syncProfileToCloud(seeded);
  }

  const data = snap.data();
  const cloudSettings = (data.settings || {}) as PlayerProfile['settings'] & {
    activeTheme?: ThemeId;
    lastFreeCoinDate?: string;
  };

  const merged: PlayerProfile = normalizeProfileForToday({
    ...localProfile,
    uid: user.uid,
    displayName: typeof data.displayName === 'string' ? data.displayName : localProfile.displayName,
    avatarId: (data.avatarId as AvatarId) || localProfile.avatarId,
    uzc: Math.max(localProfile.uzc, typeof data.uzc === 'number' ? data.uzc : 0),
    level: Math.max(localProfile.level, typeof data.level === 'number' ? data.level : 1),
    xp: typeof data.xp === 'number' ? data.xp : localProfile.xp,
    hints: Math.max(localProfile.hints, typeof data.hints === 'number' ? data.hints : 0),
    powerups: {
      revealLetter: Math.max(localProfile.powerups.revealLetter, data.powerups?.revealLetter || 0),
      freezeTime: Math.max(localProfile.powerups.freezeTime, data.powerups?.freezeTime || 0),
      scrambleRival: Math.max(localProfile.powerups.scrambleRival, data.powerups?.scrambleRival || 0),
      skipWord: Math.max(localProfile.powerups.skipWord || 0, data.powerups?.skipWord || 0),
    },
    ownedThemes: Array.from(new Set([...localProfile.ownedThemes, ...(data.ownedThemes || [])])) as ThemeId[],
    activeTheme: cloudSettings.activeTheme || localProfile.activeTheme,
    ownedAvatars: Array.from(new Set([...localProfile.ownedAvatars, ...(data.ownedAvatars || [])])) as AvatarId[],
    dailyState: {
      ...(data.dailyState || localProfile.dailyState),
      activityDays: sanitizeActivityDays([
        ...(localProfile.dailyState?.activityDays || []),
        ...(data.dailyState?.activityDays || []),
      ]),
    },
    lastFreeCoinDate: cloudSettings.lastFreeCoinDate || localProfile.lastFreeCoinDate,
    tasks: data.tasks || localProfile.tasks,
    stats: data.stats || localProfile.stats,
    settings: {
      sound: cloudSettings.sound ?? localProfile.settings.sound,
      vibration: cloudSettings.vibration ?? localProfile.settings.vibration,
      darkMode: cloudSettings.darkMode ?? localProfile.settings.darkMode,
      blueTheme: cloudSettings.blueTheme ?? localProfile.settings.blueTheme,
      hardMode: cloudSettings.hardMode ?? localProfile.settings.hardMode,
    },
  });

  saveLocalProfile(merged);
  return merged;
}
