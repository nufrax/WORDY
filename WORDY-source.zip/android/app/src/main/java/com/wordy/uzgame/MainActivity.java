package com.wordy.uzgame;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
