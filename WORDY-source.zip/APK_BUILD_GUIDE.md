# WORDY.apk — GitHub + Capacitor yigʻish qoʻllanmasi

Loyihada **Capacitor Android** (`com.wordy.uzgame`) va **GitHub Actions** (`.github/workflows/build-apk.yml`) toʻliq sozlangan.

## 1. GitHub’ga yuklash
1. AI Studio’dan loyihani ZIP qilib yuklab oling (yoki GitHub’ga ulaning).
2. GitHub’da yangi repository yarating va barcha fayllarni `main` branch’ga yuklang.
3. Yuklanishi bilan **Actions** boʻlimida `Build WORDY.apk (Capacitor Android)` avtomatik ishga tushadi va tayyor **`WORDY.apk`** faylini yaratadi.

## 2. Imzo (Signature) muammosini bir marta va abadiy hal qilish
Yangi `WORDY.apk` chiqqanda eski oʻyinni oʻchirmasdan ustiga oʻrnatish uchun **bitta doimiy Keystore** dan foydalanish kerak:

1. Kompyuterda (yoki Android Studio’da) bir marta kalit yarating:
   ```bash
   keytool -genkey -v -keystore wordy-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias wordy_key
   ```
2. Faylni Base64 koʻrinishiga oʻtkazing:
   - Linux/Mac: `base64 -w 0 wordy-release.jks`
   - Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("wordy-release.jks"))`
3. GitHub Repository → **Settings → Secrets and variables → Actions → New repository secret** boʻlimiga quyidagi 4 ta secret qoʻshing:
   - `KEYSTORE_BASE64` — Base64 matni
   - `KEYSTORE_PASSWORD` — keystore paroli
   - `KEY_ALIAS` — `wordy_key`
   - `KEY_PASSWORD` — kalit paroli

Shundan soʻng har safar kod yangilanganda `WORDY.apk` **aynan bir xil imzo** va oʻsib boruvchi `versionCode` bilan chiqadi — telefon eski ilovani oʻchirmasdan yangilayveradi.
