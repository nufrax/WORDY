# WORDY — Oʻzbekcha Interaktiv Soʻz Oʻyini (UZC Iqtisodiyoti)

**WORDY** — inglizcha soʻzlarni topishga asoslangan, toʻliq oʻzbek tilidagi interfeysga ega, UZC (Uz Coin) ichki valyuta tizimi, 5 ta asosiy oʻyin rejimi hamda onlayn, AI bot va oflayn taklif kodi orqali oʻynaladigan bellashuvlarni oʻz ichiga olgan interaktiv 2D soʻz oʻyini.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> Quyidagi qarorlar foydalanuvchi javoblari asosida tasdiqlandi va tizim arxitekturasiga toʻliq kiritildi:

- **Tasdiqlangan qaror 1 (Lugʻat tili)**: Barcha jumboq soʻzlari faqat **inglizcha soʻzlar**dan iborat boʻladi (masalan, `APPLE`, `DREAM`, `MAGIC`, shuningdek Classic rejimi uchun maxsus 6 harfli inglizcha soʻzlar bazasi).
- **Tasdiqlangan qaror 2 (Together duellari va saqlash)**: Duellar **3 xil usulda** ishlaydi — Firebase orqali real vaqtda **Onlayn taklif kodi** bilan, aqlli **AI bot** raqiblariga qarshi va internet boʻlmaganda deterministik **Oflayn taklif kodi** / bir qurilmada bellashish imkoniyati bilan. Taraqqiyot ham mahalliy, ham Firebase bulutida saqlanadi.
- **Tasdiqlangan qaror 3 (Interfeys tili)**: Barcha menyular, tugmalar, topshiriqlar, sozlamalar va xabarlar **faqat oʻzbek tilida** boʻladi.
- **Tasdiqlangan qaror 4 (Classic Wordle uzunligi)**: **Classic** rejimida faqat **6 harfli inglizcha soʻzlar** ishlatiladi (6 ta urinish).

---

### 1. Umumiy Koʻrinish va Asosiy Konsepsiya

- **Nima qiladi**: Foydalanuvchiga bitta yaxlit oʻyin qobigʻida 5 ta mustaqil soʻz jumboq rejimini (`Classic`, `Daily`, `Circle`, `Mixed`, `Together`), `UZC` tanga iqtisodiyotini, daraja (XP) tizimini, kunlik/haftalik topshiriqlarni va doʻkonni taqdim etadi.
- **Kimlar uchun**: Inglizcha soʻz boyligini oshirishni va doʻstlar yoki AI botlar bilan tezkor aqliy bellashuvlarda qatnashishni yoqtiradigan oʻzbek tilida soʻzlashuvchi oʻyinchilar.
- **Asosiy qiymat**: Har bir topilgan soʻz va yutilgan duel oʻyinchiga **UZC** tangalar va **XP** olib keladi; topilgan UZC tangalar esa doʻkonda maslahatlar (`Maslahat`), strategik jang kuchaytirgichlari, avatarlar va mavzular sotib olishga sarflanadi.

---

### 2. Foydalanuvchi Tajribasi va Vizual Dizayn

#### Asosiy Foydalanuvchi Oqimlari

1. **Bosh ekran (Oʻyin qobigʻi)**:
   - Yuqori panelda oʻyinchi avatari, ismi, daraja va XP chizigʻi (`12-daraja`) hamda **UZC** balansi (`1234 UZC` + doʻkonga oʻtish tugmasi).
   - Markazda tojli **WORDY** emblemasi va 5 ta asosiy oʻyin rejimi tugmalari:
     - **CLASSIC** (*6 harfli Wordle*)
     - **DAILY** (*Kunlik 5 ta soʻz*)
     - **CIRCLE** (*4–10 harfli soʻzlar*)
     - **MIXED** (*Chalkash soʻzlar*)
     - **TOGETHER** (*Doʻst bilan duel*)
   - Pastki panelda real bildirishnoma raqamlariga ega 3 ta boʻlim: **Doʻkon** (*Tangalar*), **Sozlamalar**, **Topshiriqlar**.
2. **Oʻyin rejimlari jarayoni**:
   - **Classic (6×6 Wordle)**: 6 ta urinishda 6 harfli inglizcha soʻzni topish. Jismoniy klaviatura va ekrandagi QWERTY klaviatura qoʻllab-quvvatlanadi. Harflar `Yashil` (toʻgʻri joy), `Sariq` (boshqa joyda bor) va `Kulrang` (mavjud emas) ranglarda 3D aylantirish animatsiyasi bilan ochiladi. Qiyin rejim (`Hard Mode`) yoqilganda topilgan ishoralarni keyingi qatorda ishlatish majburiy boʻladi.
   - **Daily (Kunlik 5 ta soʻz)**: Sana asosida har kuni yangilanadigan 5 ta inglizcha soʻz zanjiri (1 dan 5 gacha bosqichma-bosqich, oxirgi 5-soʻzda sovgʻa sandigʻi). Har bir yechilgan soʻz belgilangan holatda saqlanadi, hammasi topilganda katta UZC mukofoti beriladi.
   - **Circle (Harflar gʻildiragi)**: Aylana boʻylab joylashgan harflarni sichqoncha/barmoq bilan tortib chizish (SVG bogʻlovchi chiziq) yoki ketma-ket bosish orqali 4–10 harfli soʻzlar tuzish. Qoʻshimcha bonus soʻzlar uchun qoʻshimcha UZC, `Maslahat` (harf ochish) va `Aralashtirish` (harflar oʻrnini almashtirish) tugmalari mavjud.
   - **Mixed (Chalkash soʻzlar)**: Aralashtirilgan harflardan toʻgʻri soʻzni tartib bilan terish (`R E A T M` → `M A T E R` yoki `T R E A M` kabilar). Bosish yoki klaviatura orqali kiritish, `Maslahat` va `Aralashtirish` boshqaruvlari.
   - **Together (Duel markazi)**: Uch xil bellashuv turi (`Classic Duel` — 2 daqiqa / 5 raund; `Battle Duel` — 3 daqiqa / 6 raund + strategik kuchaytirgichlar; `Team Duel` — 3 daqiqa / 10 raund, *Koʻk jamoa* vs *Qizil jamoa*). Har birida 3 ta ulanish rejimi tanlanadi: **Onlayn taklif kodi**, **AI Bot**, **Oflayn taklif kodi / Bir qurilma**.
3. **Gʻalaba va Mukofot oynasi**:
   - Oltin kubok, `"Ajoyib!"` lentalari, qoʻlga kiritilgan `+UZC` va `+XP` miqdori, `"Davom etish"` tugmasi bilan silliq yakunlanadi.

#### Vizual Identitet va Mavzu

- **Estetik yoʻnalish**: Jonli, taktil va yuqori kontrastli arkada-jumboq uslubi (toʻyingan quyoshli qahrabo, chuqur tun koʻki, zumrad yashil va moviy-binafsha duel arenalari).
- **Rang tizimi (60-30-10 va Ikki Mavzu)**:
  - *60% Asosiy arena foni*: Quyoshli qahrabo-oltin (`#F97316` / `#FB923C` bosh ekranda), chuqur indigo-koʻk (`#0F172A` / `#1E3A8A` oʻyin maydonlarida) va Dark Mode yoqilganda silliq toʻq kulrang-tun (`#0B1120`) oʻzgarishi (`@custom-variant dark`).
  - *30% Strukturaviy sirtlar*: Krem-sariq tugma kartalari (`#FEF3C7` / `#FDE68A`), aniq chegarali katakchalar va oʻyin klaviaturasi.
  - *10% Aksent va holatlar*: Toʻgʻri harf uchun zumrad yashil (`#16A34A`), notoʻgʻri oʻrin uchun iliq sariq (`#EAB308`), UZC tangalari uchun oltin (`#F59E0B`), duel jamoalari uchun koʻk (`#2563EB`) va qizil (`#DC2626`). Barcha holatlar rang bilan birga shakl/belgi/matn bilan ham koʻrsatiladi.
- **Tipografiya (2+1 qoidasi)**:
  - *Sarlavha va katta yozuvlar*: `Fredoka` / `Outfit` — yumshoq, oʻyinbop va juda aniq koʻrinadigan display shrift.
  - *Asosiy matn va tugmalar*: `Plus Jakarta Sans` — oʻzbekcha maxsus harflar (`oʻ`, `gʻ`, `sh`, `ch`) bilan mukammal oʻqiladigan toza shrift.
  - *Hisoblagichlar va kodlar*: `JetBrains Mono` (`tabular-nums`) — UZC balansi, taymer va taklif kodlari sakramasligi uchun.
- **Interaktiv aks-sado va Ovoz**:
  - Har bir harf bosilganda, qator tebranganda (`shake`), toʻgʻri soʻz topilganda va UZC qoʻshilganda **Web Audio API** orqali sintezlangan ovoz effektlari va `navigator.vibrate` (Sozlamalarda yoqish/oʻchirish mumkin).
  - Barcha animatsiyalar faqat `transform` va `opacity` xossalari orqali (`<= 200ms`) ishlaydi.

---

### 3. Asosiy Mahsulot Qarorlari va Muvozanatlar

- **Qaror 1: Uch tomonlama Duel Arxitekturasi (Onlayn + AI Bot + Oflayn Kod)**
  - *Tanlangan yondashuv*:
    - **Onlayn Duel**: Firestore `duelRooms` kolleksiyasida real vaqt (`onSnapshot`) sinxronizatsiyasi va 6 belgili taklif kodi (`masalan, WRD742`).
    - **Oflayn Taklif Kodi**: Ikki oʻyinchi internetsiz ham bir xil 6 belgili urugʻ-kodni (`seed code`) kiritib, deterministik PRNG orqali aynan bir xil soʻzlar toʻplami va raundlarda bellashishi (yoki bitta ekranda navbat bilan oʻynashi) mumkin.
    - **AI Bot**: Raqibning oʻylash tezligi va xato ehtimolini modellashtiruvchi haqiqiy qadam-baqadam AI raqib (Battle Duelda strategik kuchaytirgichlar ham ishlatadi).
  - *Nega*: Foydalanuvchi soʻragan uchala ssenariyda ham (internet bor-yoʻqligidan qatʼi nazar) duel doimo ishlaydi.
- **Qaror 2: Gibrid Saqlash (Mahalliy + Firebase Bulut)**
  - *Tanlangan yondashuv*: Oʻyinchi kirgan zahoti `localStorage` orqali darhol oʻynay oladi; **Sozlamalar → Taraqqiyotni saqlash** yoki Google orqali kirilganda barcha UZC, XP, yechilgan topshiriqlar va doʻkon xaridlari Firebase Auth + Firestore profili bilan birlashtiriladi.
  - *Nega*: Roʻyxatdan oʻtish devorisiz tezkor kirish, shu bilan birga qurilmalararo haqiqiy bulut saqlash.
- **Qaror 3: Kengaytirilgan Inglizcha Lugʻat va Validatsiya**
  - *Tanlangan yondashuv*: Ichki kuratsiyalangan 6 harfli (Classic uchun), 5 harfli (Daily/Duel uchun) va 4–10 harfli (Circle/Mixed uchun) keng inglizcha lugʻat hamda validatsiya toʻplami, shunda oʻyinchi kiritgan haqiqiy inglizcha soʻzlar (masalan, `PLANET`, `STREAM`, `APPLE`, `BRIGHT`, `MASTER`) xatosiz qabul qilinadi.

---

### 4. Texnik Arxitektura va Maʼlumotlar Strategiyasi

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           WORDY OʻYIN QOBIGʻI                           │
│  ┌──────────────┐   ┌───────────────────────┐   ┌────────────────────┐  │
│  │  Oʻyinchi    │   │   Mavzu / Ovoz /      │   │  Firebase Provayder │  │
│  │  Profili     │◄─►│   Sozlamalar          │◄─►│  (Auth + Firestore)│  │
│  │  (UZC & XP)  │   │   (Web Audio, Dark)   │   │                    │  │
│  └──────┬───────┘   └───────────────────────┘   └─────────┬──────────┘  │
└─────────┼─────────────────────────────────────────────────┼─────────────┘
          │                                                 │
          ▼                                                 ▼
┌───────────────────────────┐                 ┌───────────────────────────┐
│   5 Ta Oʻyin Rejimi       │                 │  Xizmat Modullari         │
│  ┌─────────────────────┐  │                 │  • duelRooms (Onlayn)     │
│  │ Classic (6-harfli)  │  │                 │  • users/{uid} (Saqlash)  │
│  │ Daily (5 ta soʻz)   │  │                 │  • Deterministik Seed     │
│  │ Circle (Gʻildirak)  │  │◄───────────────►│  • AI Bot Simulyatori     │
│  │ Mixed (Chalkash)    │  │                 │  • Lugʻat & Tekshiruv     │
│  │ Together (3 Duel)   │  │                 │  • Topshiriqlar Kuzatuvi  │
│  └─────────────────────┘  │                 └───────────────────────────┘
└───────────────────────────┘
```

#### Maʼlumotlar Modeli va Holatlar

- **Oʻyinchi Holati**: `displayName`, `avatarId`, `uzc` (Uz Coin balansi), `xp`, `level`, `hints` (maslahatlar soni), `powerups` (Battle Duel uchun muzlatish/ochish/bloklash), `ownedThemes`, `ownedAvatars`, `dailyState` (bugungi 5 ta soʻz holati), `tasks` (kunlik/haftalik/yutuq progresslari), `settings` (ovoz, tebranish, tungi rejim, moviy mavzu, qiyin rejim).
- **Onlayn Duel Xonasi (`duelRooms/{roomId}`)**:
  - `inviteCode` (6 belgili kod), `variant` (`classic_duel` | `battle_duel` | `team_duel`), `status` (`waiting` | `active` | `finished`), `words` (raundlar uchun inglizcha soʻzlar roʻyxati), `currentRound`, `players` (har bir oʻyinchi UID, jamoa — `blue`/`red`, ball, tayyorlik va aktiv kuchaytirgich holati), `expiresAt` / `createdAt`.
- **Xavfsizlik va Qoidalar**:
  - `firebase-blueprint.json` va qatʼiy `firestore.rules` (foydalanuvchi faqat oʻz profilini tahrirlay oladi, duel xonasida esa faqat ishtirokchilar oʻz ball/holat maydonlarini yangilay oladi, yakunlangan oʻyin holati muzlatiladi).
  - Barcha Firestore soʻrovlarida xatolik yuzaga kelsa, tizimli `handleFirestoreError` ishlaydi.

#### Interaktiv Komponentlar va Holatlar Xaritasi

- **Soʻz kiritish va tekshirish**: Klaviatura tugmalari (ekran + jismoniy) bir xil hodisa boshqaruvchisi orqali ishlaydi; notoʻgʻri uzunlik yoki lugʻatda yoʻq soʻzda qator tebranish animatsiyasi va oʻzbekcha ogohlantirish chiqadi.
- **Circle gʻildiragi**: `PointerDown` / `PointerMove` / `PointerUp` hodisalari orqali harflar ustidan sirpanish chizigʻini chizadi va bosish orqali ham harf qoʻshishni qoʻllab-quvvatlaydi.
- **Battle Duel strategiyasi**: Oʻyinchilar UZC evaziga sotib olingan yoki duelda berilgan kuchaytirgichlardan (`Harf ochish`, `Vaqt qoʻshish`, `Raqibni chalgʻitish`) raund davomida real vaqtda foydalana oladi.
- **Topshiriqlar va Doʻkon**: Har bir tugallangan oʻyin avtomatik ravishda tegishli topshiriq hisoblagichini oshiradi; tayyor topshiriqlar `"Mukofotni olish"` tugmasi bosilganda UZC balansiga qoʻshiladi va badge soni yangilanadi.
